This directory contains files used for docking

	"ligands" folder contains ligand files prepared for docking (antibiotics FOT: cefotaxime, TAZ: ceftazidime, NIT: nitrocefin)

	"receptors" folder contains receptor files prepared (at different pHs) for docking. (1zc2mono is cmy, and 4hbt is ctx)
	
	#vinaOutput" folder contains result of docking each ligand in each receptor