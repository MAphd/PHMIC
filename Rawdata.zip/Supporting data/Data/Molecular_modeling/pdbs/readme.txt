This directory contains 2 pdbs from public databases:

4hbt.pdb : crystal structure of CTX-M-15

1zc2mono.pdb : crystal structure of CMY-2
	was modified from the original by deletion of "assembly 2" chain