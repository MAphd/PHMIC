This directory contain the results from MIC panels (EUVSEC2, Thermo Fisher).
Files are tsv format tables with MIC readings, condition (media pH).

Contents are: 
	"EUVSEC2panelresults.txt" Contains MICs of strains: K12, K12 CTX, K12 CMY, K12 CMYCTX, A. baumannii at different pHs.

	"EUVSEC2panelwtemperatureresults.txt" Contains MICs of strains: K12, K12 CTX, K12 CMY, K12 CMYCTX, A. baumannii at different pHs and temperatures.
	
	"ClinicalCTXorCMYisolates.txt" Contains MICs of several clinical strains with either CTX-M-15 or CMY-2. 
	We tested 10 isolates in total, 5 with CTX and 5 with CMY, however we had to exclude 3 isolates:
	Isolate 1 was excluded since this was not E. coli, but Proteus mirabilis
	Isolate 5 was excluded as it contained additional resistance adaptation related to cephalosporin resistance (ftsI_N337NYRIN mutation)
	Isolate 7 was excluded as it contained additional resistance adaptation related to cephalosporin resistance (ftsI_I336IKYRI mutation)
