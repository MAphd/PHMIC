This directory contains kinetic reads from enzyme experiments.

Folders "nitrocefincmy" and "nitrocefinctx" contain data from experiments where nitrocefin is being degraded by CMY or CTX (as the name indicates).
	These folders contain subfolders named according to experimental conditions (pH), and each folder contains 8 txt files:
	Files named "Rep" 1-4 are experiments with a high initial substrate concentration (materials and methods), while files named "nit6" or "nit10" contain 6.5µg/ml or 10µg/ml nitrocefin. 
	
Folder "ceftazidimectx" contain data from experiments where ceftazidime is being degraded by CTX. TODO: add these
	This folders contain subfolders named according to experimental conditions (pH), and each folder contains 8 txt files:
	Files named "Rep" 1-4 are experiments with a high initial substrate concentration (materials and methods), while files named "TAZ50" contain 50µg/ml ceftazidime. 
	
	
Each file contains data from a sample run where we continuously measure absorbance of 4 wells in a specific layout: 
(ascii example of layout, wells are labeled 1-4, wells 1 and 2 are at the top, while 3 and 4 are at the bottom in a square in a microplate). 
	 --- ---
	|  1|  2|
	|___|___|
	|  3|  4|
	|___|___|

Wells 1 and 2 contain solvent controls (UB4 buffer and BSA at the indicated pH but no antibiotic).
Well 3 contain antibiotic + enzyme
Well 4 contain antibiotic but no enzyme (substituted by an equal volume of water)
	
	