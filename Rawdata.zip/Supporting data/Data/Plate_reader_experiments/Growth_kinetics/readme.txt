This directory contains raw data from growth kinetics of strains 

K12 
K12 CTX
K12 CMY
K12 CMYCTX

Plates were designed as broth microdilution panels with the highest concentration of ceftazidime in the first column (final conc 64µg/ml).
The concentration is two-fold diluted each column to the 10th column: column 11 and 12 are positive and negative growth controls, respectively (containing no antibiotic)
Files are all named according to the pH of the medium and a specific layout of strains:

"Plate 1" layout is as follows: 
Rows A and B contain K12 
Rows C, D, and E, contain K12 CTX 
Rows F, G, and H, contain K12 CMY

"Plate 3" layout is as follows:
Rows A and B contain K12
Rows C, D, and E, contain K12 CTXCMY (not used for this publication)
Rows F, G, and H, contain K12 CMYCTX