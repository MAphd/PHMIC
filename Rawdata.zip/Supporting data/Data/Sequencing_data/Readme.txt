This directory contain the results used to verify strains

	K12wt.fasta - Hybrid de-novo assembly (using long and short sequences) of the K12 wild-type isolate
	
	K12CMY.fasta - de-novo assembly (using only short read sequences) of the K12 CMY strain
	
	K12CTX-M.fasta - de-novo assembly (using only short read sequences) of the K12 CTX-M strain
	
	
	