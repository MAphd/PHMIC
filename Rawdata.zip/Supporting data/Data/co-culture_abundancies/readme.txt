This directory contains results for co-cultures

	folder "KMAdatabase" contains the fasta file used to create KMA database, and the resulting database (in folder bladb3k28)

	Text files Coculture (1-3) results contain .tsv files with proportions of each isolate calculated and experimental conditions.
	