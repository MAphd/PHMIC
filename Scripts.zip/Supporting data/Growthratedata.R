

library(readr)
library(ggplot2)
library(lubridate)


HERE <- dirname(rstudioapi::getSourceEditorContext()$path)

# source("Functions.R")

files <- list.files(paste0(HERE,"/data/Plate_reader_experiments/Growth_kinetics/") ,pattern = "txt")

files <- files[grepl("Plate",files)]

#Build "Dulldata"
Dulldata <- data.frame()
for(z in 1:length(files)){
  
  Data <- suppressMessages(read_delim(paste0(HERE,"/data/Plate_reader_experiments/Growth_kinetics/",files[z]) ,
                                      delim = "\t", escape_double = FALSE,
                                      locale = locale(decimal_mark = ",", grouping_mark = "."),
                                      trim_ws = TRUE))
  print(files[z])
  
  #Shitty way to grab pH of plate:
  PH <- as.numeric(strsplit( unlist(strsplit(files[z], "pH", fixed = TRUE)), ".txt", fixed = TRUE)[[2]])
  
  Plate <- as.numeric(unlist(strsplit( strsplit( unlist(strsplit(files[z], "Plate ", fixed = TRUE)), ".txt", fixed = TRUE)[[2]], " ", fixed = TRUE))[1])
  
  #spectramax plate conversion
  if(identical(colnames(Data)[2],"Temperature(¡C)") ){
    Time <- as.numeric(hms(Data[,1][[1]]))
    Time <- Time/60
  } else {
    #Thermofisher plate
    
    Time <- as.vector(Data[,2])[[1]]
    Time <- ceiling(Time)
    #Convert time to minutes
    Time <- Time/60
    
    
  }
  
  
  

  Tdiff <- mean(diff(Time))
  #Remove columns 1, 2 and 99
  Data <- Data[,-c(1,2,99)]
  
  
  # Data <- Data[-332,]
  
  Fulldata <- data.frame()
  #Iterate across columns, assuming 96 wells (8x12, row x columns)
  for(i in 1:96 ){
    
    #every "i" is a new row
    
    #Format: Time, Data, well, column, strain, biorep
    Fulldata <- rbind(Fulldata, cbind(Time, (as.vector(Data[,i]))[[1]], colnames(Data[,i]), 1+((i+11)%%12), c(64,32,16,8,4,2,1,0.5,0.25,0.125,0,0)[1+((i+11)%%12)],  if(i<=24){ 1}else if(i<=60){2 }else{ 3}, if(i<=12){ 1}else if(i<=24){2 }else{  1+((1+ceiling((i-12)/12))%%3)   }, z, PH, Plate ) )
    
    
    
  }
  colnames(Fulldata) <- c("Time","OD","Well","Column","Conc","Strain","Biorep","Plate","pH","platelayout")
  
  Fulldata$Conc <- as.numeric(Fulldata$Conc)
  Fulldata$OD <- as.numeric(Fulldata$OD)
  Fulldata$Time <- as.numeric(Fulldata$Time)
  Fulldata$Biorep <- as.numeric(Fulldata$Biorep)
  Fulldata$Column <- as.numeric(Fulldata$Column)
  Fulldata$logOD <- log2(Fulldata$OD)
  Fulldata$Strain <- as.numeric(Fulldata$Strain)
  # 
  Fulldata$file <- files[z]
  
  Dulldata <- rbind(Dulldata, Fulldata)
  
}


Files2 <- list.files(paste0(HERE,"/Data/Growth_rates/") ,pattern = ".txt$")


Files2 <- Files2[grepl("Plate",Files2)]

Finaldata <- data.frame()
for( i in 1:length(Files2)){
  
  test1 <- read_tsv(paste0(HERE,"/Data/Growth_rates/",Files2[i]) )
  
  colnames(test1) <- c("Strain","Biorep","Column","Conc","X1","X2","gentime","Slo","Interc","Modelscore","pH","Well","File","Elapsed","x4","x5","x6","platelayout")
  
  # test1$file <- Files2[i]
  
  test1$Strain2 <- 0
  
  test1$Strain2[test1$Strain == 1] <- "K12"
  
  if(identical(test1$platelayout[1], 3 )){
    
    test1$Strain2[test1$Strain == 2] <- "CTXCMY"
    test1$Strain2[test1$Strain == 3] <- "CMYCTX"
    
  }
  if(identical(test1$platelayout[1], 1 )){
    
    test1$Strain2[test1$Strain == 2] <- "CTX"
    test1$Strain2[test1$Strain == 3] <- "CMY"
    
  }
  if(identical(test1$platelayout[1], 5 )){
    test1$Strain2 <- 0
    
    
    test1$Strain2[grepl("[BCD]",test1$Well)] <- "SP1 SPctx-CMY"
    
    test1$Strain2[grepl("[EFG]",test1$Well)] <- "SP2 SPcmy-CTX"
  }
  
  
  
  Finaldata <- rbind(Finaldata, test1 )
  
  
  
}



#Shitty workaround since pH was NA
Finaldata$pH[Finaldata$File == unique(Finaldata$File[which(is.na(Finaldata$pH))]) ] <- 7




Dulldata$Strain2 <- 0

Dulldata$Strain2[Dulldata$Strain == 1] <- "K12"


  
Dulldata$Strain2[Dulldata$Strain == 2 & Dulldata$platelayout == 3] <- "CTXCMY"
Dulldata$Strain2[Dulldata$Strain == 3 & Dulldata$platelayout == 3] <- "CMYCTX"
  


  
Dulldata$Strain2[Dulldata$Strain == 2 & Dulldata$platelayout == 1] <- "CTX"
Dulldata$Strain2[Dulldata$Strain == 3 & Dulldata$platelayout == 1] <- "CMY"

Dulldata$Strain2[Dulldata$Strain == 2 & Dulldata$platelayout == 1] <- "CTX"
Dulldata$Strain2[Dulldata$Strain == 3 & Dulldata$platelayout == 1] <- "CMY"
  


#Calculate lagtimes (e.g. when exponential phase can be detected and when it stops)
Finaldata$sEXP <- (-3.4-Finaldata$Interc)/Finaldata$Slo
Finaldata$eEXP <- 0

Finaldata$sEXP2 <- 0

for(i in 1:dim(Finaldata)[1]){
  
  #Find corresponding Dulldata for each Finaldata row, link by well and file?
  
  A1 <- Finaldata[i,]
  
  A2 <- max(subset(Dulldata$logOD,Dulldata$file == A1$File[1] & Dulldata$Well == A1$Well[1] & Dulldata$Time > A1$sEXP[1] ))
  # #calc eEXP for each well seperately as they may have different ODmax
  
  Finaldata$eEXP[i] <- (A2-Finaldata$Interc[i])/Finaldata$Slo[i]
  
  A2 <- min(subset(Dulldata$logOD,Dulldata$file == A1$File[1] & Dulldata$Well == A1$Well[1] ))
  
  Finaldata$sEXP2[i] <- (A2-Finaldata$Interc[i])/Finaldata$Slo[i]
  
  
}


Finaldata$eDUR <- Finaldata$eEXP - Finaldata$sEXP2




### Plot kinetics with linear regressions for each file and save to /output/

# for(i in 1:length(files) ){
# 
#   F1 <- files[i]
# 
# ggplot(subset(Dulldata,Dulldata$file == F1),aes(x = Time, y = logOD, color = Strain2 )) +
#   geom_point() +
#   geom_abline(data = subset(Finaldata, Finaldata$File == F1 ), aes(slope = Slo, intercept = Interc), color = "black", linetype = "dashed")+ #slope of exponential
#   geom_vline( data = subset(Finaldata, Finaldata$File == F1 ), aes(xintercept = sEXP2 ), color = "black", linetype = "dotted") + #start of exponential
#   geom_vline( data = subset(Finaldata, Finaldata$File == F1 ), aes(xintercept = eEXP ), color = "black", linetype = "dotted") + #end of exponential
#   facet_wrap(~Well, nrow= 8, ncol= 12) +
#   scale_color_discrete(name = "Strains")
# 
# 
# ggsave(paste0(HERE, "/",files[i],"plot.svg"), height = 8, width = 12, scale = 2, limitsize = FALSE, device ="svg")
# 
# }

#other plots with potential interest below

library(ggbeeswarm)

library(gtools)
library(RColorBrewer)
Finaldata$Conc2 <- paste0("Ceftazidime conc = ",Finaldata$Conc,"ug/ml")

Finaldata$Conc2 <- factor(Finaldata$Conc2, levels = mixedsort(unique(Finaldata$Conc2)))
PLOTCOL <- brewer.pal(8,"Set1")

Finaldata$Strain3 <- factor(Finaldata$Strain2,levels = unique(Finaldata$Strain2))


levels(Finaldata$Strain3)
Finaldata$Strain3 <- (factor(Finaldata$Strain3, labels = c("K12","CTXCMY","CMYCTX","CTX-M-15","CMY-2")))


Finaldata$relg <- Finaldata$Slo / mean(Finaldata$Slo[Finaldata$Strain3 == "K12" & Finaldata$pH == 7 & Finaldata$Conc == 0])
Finaldata$relg <- Finaldata$relg*100

#make ph2 parameter for facet titles

Finaldata$pH2 <- paste0("pH = ",Finaldata$pH)

#Write finaldata.txt for fitnesslandscape plots
write_tsv(Finaldata, paste0(HERE,"/Data/Fitnesslandscape/Finaldata.txt"))

GRplot <- ggplot(subset(Finaldata, Finaldata$Strain2 != "CTXCMY" & Finaldata$Strain2 %in% c("K12","CTX","CMY","CMYCTX") ), aes(x = pH, y = (relg),fill = Strain3, group = interaction(Strain3, pH))) +
  # geom_point() +
  # geom_boxplot() +
  # geom_violin()+
  scale_fill_manual(values = PLOTCOL, name = "Strains") +
  # scale_shape_discrete(name = "Strains") +
  # scale_color_discrete(name = "Strains")+ 
  geom_quasirandom(stroke = 1, shape = 21, width = 0.4, size = 3 )+
  # geom_quasirandom(width = 0.4, shape  )+
  # geom_dotplot() +
  # geom_smooth(method = lm)+
  # stat_regline_equation(aes(label = after_stat(eq.label)), label.y = 14) +
  # stat_cor(aes(label = paste(..rr.label..)),r.accuracy = 0.01,label.y = 13) +
  facet_wrap(~Conc2, nrow = 4) +
  theme_bw() +
  theme(axis.line = element_line(colour = "black"),
        # panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # panel.border = element_blank(),
        # panel.background = element_blank()
  ) +
  ylab("Relative growth rate [%]")



library(ggpubr)
library(RColorBrewer)
library(ggbeeswarm)

compare_means(Slo~Strain2, Finaldata, method = "t.test",p.adjust.method = "fdr")

# anova(aov(Slo~pH+Conc+Strain2, subset(Finaldata, Finaldata$Strain2 != "CTXCMY" & Finaldata$Conc == 0)))

ggplot(subset(Finaldata, Finaldata$Strain2 %in% c("CTX","CMY","SP1 SPctx-CMY","SP2 SPcmy-CTX") ), aes(x = pH, y = sEXP2,fill = Strain2, group = interaction(Strain2, pH))) +
  # geom_point() +
  # geom_boxplot() +
  # geom_violin()+
  scale_fill_manual(values = brewer.pal(8,"Set1")[c(3,2,7,8)], name = "Strains") +
  # scale_shape_discrete(name = "Strains") +
  # scale_color_discrete(name = "Strains")+ 
  geom_quasirandom(stroke = 1, shape = 21, width = 0.4, size = 3 )+
  # geom_quasirandom(width = 0.4, shape  )+
  # geom_dotplot() +
  # geom_smooth(method = lm)+
  # stat_regline_equation(aes(label = after_stat(eq.label)), label.y = 14) +
  # stat_cor(aes(label = paste(..rr.label..)),r.accuracy = 0.01,label.y = 13) +
  facet_wrap(~Conc, nrow = 4) +
  theme_bw() +
  theme(axis.line = element_line(colour = "black"),
        # panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # panel.border = element_blank(),
        # panel.background = element_blank()
  ) 
  ylab("Relative growth rate [%]")



library(ggpubr)
plotFilament <- ggarrange(
ggplot(subset(Dulldata,Dulldata$file == "new_16012025 Plate 1 pH 5.txt" & Strain2 == "CTX" & Conc %in% c(0,64) & (!Well %in% c("C12","D12","E12")) & Biorep == 2 & Conc == 0) , aes(x = Time, y = OD ))+
  geom_point() +
  # facet_wrap(~Conc)+
  scale_y_continuous(trans = "log2") +
  geom_vline(xintercept = 200)+
  coord_cartesian(xlim = c(200,1000)) +
  xlab("Time [min]") +
  ylab("log OD"),
ggplot(subset(Dulldata,Dulldata$file == "new_16012025 Plate 1 pH 5.txt" & Strain2 == "CTX" & Conc %in% c(0,64) & (!Well %in% c("C12","D12","E12")) & Biorep == 2 & Conc == 64) , aes(x = Time, y = OD ))+
  geom_point() +
  # facet_wrap(~Conc)+
  scale_y_continuous(trans = "log2") +
  geom_vline(xintercept = 200)+
  coord_cartesian(xlim = c(200,1000)) +
  xlab("Time [min]") +
  ylab("log OD"), ncol = 1, labels = c("C","D") )




ggplot(subset(Finaldata, Finaldata$Strain2 == "CMYCTX" ), aes(x = Conc, y = relg, color = as.factor(pH))) +
  # geom_point() +
  # geom_boxplot() +
  # scale_color_manual(values = PLOTCOL, name = "Strains") +
  # scale_fill_manual(values = PLOTCOL, name = "Strains") +
  # scale_x_log10() +
  scale_x_continuous(trans = scales::pseudo_log_trans(base = 2), breaks = c(0.25, 1, 4, 16)) +
  # coord_cartesian()
  # geom_quasirandom(shape = 21, width = 0.4, size = 3 )+
  geom_smooth(se=TRUE, aes(fill = as.factor(pH))) 

# View(subset(Finaldata, Finaldata$Strain2 != "CTXCMY" & Finaldata$Strain2 %in% c("K12","CTX","CMY","CMYCTX") & Finaldata$pH == 6 & Finaldata$Conc == 8   ))

GRplot2 <- ggplot(subset(Finaldata, Finaldata$Strain2 != "CTXCMY" & Finaldata$Strain2 %in% c("K12","CTX","CMY","CMYCTX")   ), aes(x = (Conc), y = sEXP, color = Strain3, group = interaction(Strain3, pH))) +
  # geom_point() +
  # geom_boxplot() +
  scale_color_manual(values = PLOTCOL, name = "Strains") +
  scale_fill_manual(values = PLOTCOL, name = "Strains") +
  # scale_x_log10() +
  scale_x_continuous(trans = scales::pseudo_log_trans(base = 2), breaks = c(0,1,2, 4,8, 16,32,64)) +
  # coord_cartesian()
  # geom_quasirandom(shape = 21, width = 0.4, size = 3 )+
  geom_smooth(aes(fill = Strain3)) +
  xlab("Ceftazidime concentration [µg/ml]")+
  # geom_pointrange() +
  # geom_errorbar(data = YIKES, aes(ymin = meanslo-sdslo, ymax = meanslo+sdslo)) +
  # stat_summary(geom = "pointrange", fun.ymin = "min", fun.ymax = "max") +
  # stat_summary(geom="ribbon", fun.min="min", fun.max="max", aes(fill=Strain3), alpha=0.3) +
  # stat_regline_equation(aes(label = after_stat(eq.label)), label.y = 14) +
  # stat_cor(aes(label = paste(..rr.label..)),r.accuracy = 0.01,label.y = 13) +
  facet_wrap(~pH2, nrow = 4) +
  theme_bw() +
  theme(axis.line = element_line(colour = "black"),
        # panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # panel.border = element_blank(),
        # panel.background = element_blank()
  ) +
  ylab("Relative growth rate [%]")

# source("shiftlegend2.R")
#GRplot2 <- shift_legend2(GRplot2)
# ggsave("GRplot.svg",plot = GRplot2, device ="svg",height = 8, width = 10, limitsize =FALSE, scale = 0.7)


