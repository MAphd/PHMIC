
library(readr)
library(ggplot2)


#Plate layouts:
#Plate 1: 4 4 4 6 6 6 10 10
#Plate 2: 10 9 9 9 2 2 2 H
#Plate 3: 8 8 8 7 7 7 3 3
#Plate 4: 3 5 5 5 1 1 1 H


# Isolate 1 is TWIW_01_SAU_A1Q_007 (CMY-2)
# Isolate 2 is TWIW_02_DEU_MAG_BI_061 (CMY-2)
# Isolate 3 is TWIW_02_DEN_HVI_BM_056 (CMY-2)
# Isolate 4 is TWIW_02_CHE_ZUR_BX_012 (CMY-2)
# Isolate 5 is TWIW_02_NGA_ILE_BN_053 (CMY-2)
# Isolate 6 is TWIW_01_GHA_SEK_008 (CTX-M-15)
# Isolate 7 is TWIW_02_PAK_MUL_AC_024 (CTX-M-15)
# Isolate 8 is TWIW_02_NGA_ILE_BN_040 (CTX-M-15)
# Isolate 9 is TWIW_02_ALB_TIR_AI_026 (CTX-M-15)
# Isolate 10 is TWIW_02_KAZ_ALM_CD_036 (CTX-M-15)


CO <- function(x){ c(rev(2^(seq(-2,7))),256)[x] }
micdf <- rbind( 

data.frame( Isolate = rep(1,15),Gene = "CMY-2",  pH = c(5,5,5,6,6,6,7,7,7,8,8,8,9,9,9), replicate = c( rep(c(1,2,3),5)) , Plate = rep(4,15), Day = rep(2,15), MIC = c( CO(c(1,1,1,6,6,6,4,6,6,5,5,3,3,3,3 ))) ),

data.frame( Isolate = rep(2,15), Gene = "CMY-2", pH = c(5,5,5,6,6,6,7,7,7,8,8,8,9,9,9), replicate = c( rep(c(1,2,3),5)) ,Plate = rep(2,15), Day = rep(1,15), MIC = c( CO(c(5,5,5,4,4,4,3,3,3,3,3,3,3,3,3)) )  ),

data.frame( Isolate = rep(3,15),Gene = "CMY-2",  pH = c(5,5,5,6,6,6,7,7,7,8,8,8,9,9,9), replicate = c( rep(c(1,2,3),5)) ,Plate = rep( c(3,3,4),5), Day = rep(2,15), MIC =  c(CO(c(3,3,3, 2,2,2, 2,1,1, 1,1,1, 11,11,11))) ),

data.frame( Isolate = rep(4,15),Gene = "CMY-2",  pH = c(5,5,5,6,6,6,7,7,7,8,8,8,9,9,9), replicate = c( rep(c(1,2,3),5)) ,Plate = rep(1,15), Day = rep(1,15), MIC = c( CO(c(6,6,6,5,4,5,4,4,4,3,3,3,1,1,1))  )),

data.frame( Isolate = rep(5,15), Gene = "CMY-2", pH = c(5,5,5,6,6,6,7,7,7,8,8,8,9,9,9), replicate = c( rep(c(1,2,3),5)) ,Plate = rep(4,15), Day = rep(2,15), MIC = c( CO(c(2,2,2,2,2,2, 1,1,1, 1,1,1,11,11,11)))),

data.frame( Isolate = rep(6,15), Gene = "CTX-M-15", pH = c(5,5,5,6,6,6,7,7,7,8,8,8,9,9,9), replicate = c( rep(c(1,2,3),5)) , Plate = rep(1,15), Day = rep(1,15),MIC = c( CO(c(2,1,1,1,1,2,2,1,1,2,3,2,5,5,5)) ) ),

data.frame( Isolate = rep(7,15), Gene = "CTX-M-15",pH = c(5,5,5,6,6,6,7,7,7,8,8,8,9,9,9), replicate = c( rep(c(1,2,3),5)) ,Plate = rep(3,15), Day = rep(2,15), MIC = c( CO(c(11,11,11,11,11,11,11,11,11,11,11,1,4,4,4 )))  ),

data.frame( Isolate = rep(8,15),Gene = "CTX-M-15", pH = c(5,5,5,6,6,6,7,7,7,8,8,8,9,9,9), replicate = c( rep(c(1,2,3),5)) ,Plate = rep(3,15), Day = rep(2,15), MIC = c( CO(c(3,2,2,3,3,2,5,4,5,6,6,6,8,8,8)) ) ),

data.frame( Isolate = rep(9,15), Gene = "CTX-M-15",pH = c(5,5,5,6,6,6,7,7,7,8,8,8,9,9,9), replicate = c( rep(c(1,2,3),5)) ,Plate = rep(2,15), Day = rep(1,15), MIC = c( CO(c(2,2,1,1,1,1,2,2,2,3,2,3,5,5,5))) ),

data.frame( Isolate = rep(10,15), Gene = "CTX-M-15",pH = c(5,5,5,6,6,6,7,7,7,8,8,8,9,9,9), replicate = c( rep(c(1,2,3),5)) ,Plate = rep( c(1,1,2),5), Day = rep(1,15), MIC =c( CO(c(2,3,2,2,2,11,3,3,3,4,3,4,6,6,6 )))  )


)

library(RColorBrewer)
PLOTCOL <- brewer.pal(8,"Set1")

library(ggbeeswarm)
library(ggnewscale)

#Isolate 1 is proteus mirabilis, so we exclude this
#Resistant ftsI variant: insertions between aa 335-338 in isolate 5 & 7 (classed aztreonam, cefiderocol & cephalosporin resistant core)
#isolate 5: ftsI_N337NYRIN excluded
#isolate 7: ftsI_I336IKYRI excluded
#since we want to narrow this study to only focus on the effects of pH on CTX-M-15 or CMY-2 in "clinical isolates"


plotNATISO <- ggplot(subset(micdf, !micdf$Isolate %in% c(1,5,7)), aes(x = (pH), y = MIC, fill = Gene, group = interaction(as.factor(pH),Gene) )) +
    scale_fill_manual(values = brewer.pal(8,"Set1")[c(1,2)]) +
  # geom_jitter() +
  # geom_violin(draw_quantiles = c(0.25,0.5,0.75))+
  # ggnewscale::new_scale_fill() +
  geom_boxplot() +
  # geom_quasirandom(aes(fill =as.factor(Isolate)), color = "black", width = 0.4)+
  # geom_smooth(aes(color = as.factor(Isolate), group = interaction(Gene, Isolate)), se=FALSE) +
  # stat_summary(fun ="median", geom ="point")+
  # geom_jitter( width= 0.3)+
  scale_y_continuous(trans = "log2", breaks = c(CO(c(1,2,3,4,5,6,7,8,9,10)))) +
  theme_bw() +
  theme( panel.grid.minor = element_blank(),
         )+ #panel.grid.major = element_blank())+
  # scale_fill_manual(values = PLOTCOL[c(3,2,2,1)], name = "Gene")+
  xlab("Media pH") +
  ylab("TAZ MIC [µg/ml]") +
  geom_vline(xintercept = c(5.5, 6.5,7.5,8.5),linetype ="dashed")
  facet_wrap(~Gene)
# 
# ggsave("MICPLOTnatiso.svg", device = "svg" , height = 5)  
# 
# 
# ggarrange(plot1,plot2, widths = c(0.5,0.25), labels = c("A","B"),common.legend = TRUE) +
#   theme(legend.position = "bottom")
