library("readr")



a1 <- dir(paste0(dirname(rstudioapi::getSourceEditorContext()$path),"/Data/co-culture_abundancies/KMAoutput/Co-culture1/"),full.names = TRUE, pattern = ".res")



DfKMA <- data.frame()
for( i in 1:length(a1)){
  
  DfKMA <- rbind(DfKMA, cbind(read_table(paste0(a1[i])),basename(a1[i])) )
  
  
  
  
}
realshit <- DfKMA[,c(1,9,12)]
colnames(realshit) <- c("Gene","Depth","Sample")



# assign sample qualities (eg. conc, ph, day)
realshit$Day <- 0
realshit$PH <- 0
realshit$Conc <- 0
for(i in 1:length(unique(realshit$Sample))){
  

  B2 <- unlist(strsplit(unique(realshit$Sample)[i],".res"))[[1]]
  
  B3 <- unlist(strsplit(B2,"MG_",fixed = TRUE))[2]
  # Bindex <- grepl(B2,Smpnam)
  #Extract from name:
  
  # B3 <- strsplit(Smpnam[Bindex],paste0(B2,"_1_MG_"))
  # B4 <- unlist(strsplit(unlist(B3)[[2]],"_S"))[[1]]
  B5 <- unlist(strsplit(B3,"_",fixed=TRUE))
  # }
  
  realshit$Day[realshit$Sample == unique(realshit$Sample)[i]] <- B5[1]
  realshit$PH[realshit$Sample == unique(realshit$Sample)[i]] <- B5[2]
  realshit$Conc[realshit$Sample == unique(realshit$Sample)[i]] <- B5[3]
  
  
}

library(ggplot2)
library(gtools)

realshit$Conc <- as.numeric(realshit$Conc)
realshit$PH2 <- paste0("pH = ",realshit$PH)
realshit$Conc2 <- paste0("Ceftazidime conc = ",realshit$Conc,"ug/ml")
realshit$Conc2 <- factor(realshit$Conc2, levels = mixedsort(unique(realshit$Conc2)))


noshit <- data.frame()
for(i in 1:length(unique(realshit$Sample))){
  a2 <- subset(realshit,realshit$Sample == unique(realshit$Sample)[i] )
  
  
  
  a5 <- c("CTXM15","CMY2")

  a2$prop <- a2$Depth/sum(a2$Depth)
  
  # 
  if( identical(length(a2$Gene), as.integer(1) )){
    #Add 0 proportion samples back (in case there was 0 reads assigned to a strain) so we can plot a 0 proportion point
    
    a7 <- a2
    
    a7$Gene <- a5[!(a5%in%a2$Gene)]
    a7$prop  <- 0
    a7$Depth <- 0
    
    a2 <- rbind(a2,a7)
    rm(a7)
  } 
  
  
  
  noshit <- rbind(noshit,a2 )
  
}

library(RColorBrewer)


PLOTCOL <- brewer.pal(8,"Set1")


noshit2 <- data.frame()
#noshit fake elapsed 0 50/50 proportion data:
for(i in 1:length(unique(noshit$PH))){
  tempshit1 <- subset(noshit, noshit$PH == unique(noshit$PH)[i])
  for(j in 1:length(unique(tempshit1$Conc))){
    tempshit2 <- subset(tempshit1, tempshit1$Conc == unique(tempshit1$Conc)[j])
    
    A <- unique(tempshit2$Gene)
    
    
    
    
    noshit2 <- rbind(noshit2, data.frame(Gene = A, Depth = 0, Sample = "fake", Day = 1, PH = tempshit2$PH[1],Conc = tempshit2$Conc[1], PH2 = tempshit2$PH2[1], 
                                        Conc2 = tempshit2$Conc2[1], prop = 0.5  ))
    
    
  }
}

# noshit$Elaps <- as.numeric(as.vector(noshit$Elaps))


noshit <- rbind(noshit,noshit2)
rm(noshit2)
# noshit$Elaps <- as.factor(noshit$Elaps)

noshit$elapsed <- 0


noshit$elapsed <- factor(noshit$Day, levels = c("1","2","3","4","5") )
noshit$elapsed <- factor(noshit$elapsed, labels = c("0","24","48","72","96") )

ggplot(subset(noshit), aes(x = (elapsed), y = (prop),  group = interaction(Gene, PH,Conc))) +
  # # geom_point() 
  # new_scale_fill() +
  # scale_x_continuous(breaks = c(0,3,6,9,12))+
  # scale_y_continuous(breaks = seq(0,1,0.25)) +
  # geom_rect( inherit.aes =FALSE, ymin = -0.05, ymax = -0.4, xmin = 0, xmax = 600, fill = NA, color = "black") +
  # geom_rect(data = fakedf, inherit.aes = FALSE, ymin = -0.05, ymax = -0.4, aes(xmin = (Elaps2)+3 ,xmax =Elaps2 ,fill = as.factor(pH) ), color = NA, alpha = 0.4) +
  # geom_rect(data = fakerdf, inherit.aes = FALSE, ymin = 0, ymax = 1, aes(xmin = (Elaps2)+3 ,xmax =Elaps2 ,fill = as.factor(pH), group = interaction(Strain2, Exp2 ) ), color = NA, alpha = 0.3) +
  # scale_fill_manual(values = c("#000000","#FFFFFF"), name = "pH") +
  # coord_cartesian(xlim = c(3,12))+
  # new_scale_fill() +
  # geom_bar(stat = "identity" ,just = 1,aes(fill = Template), color = "black") +
  geom_line(aes(color = Gene ), linewidth = 1) +
  # geom_smooth(aes(color = Template), se =FALSE) +
  geom_point(data = subset(noshit,noshit$prop >0 & noshit$Depth > 0), aes(color = Gene), size = 2) +
  scale_color_manual(values = PLOTCOL[c(1,2,4,1)], name = "Genes")+
  # geom_line() +
  # facet_wrap(~Exp2*Strain2) #, labeller = labeller(Strain2 = function(x) {rep("", length(x))}) ) +
  facet_wrap(~PH2*Conc2)+
  theme_bw() + 
  theme(
    panel.grid.minor = element_blank(),
    # panel.grid.major = element_blank()
  ) +
  ylab("Proportion [%]") +
  xlab("Time elapsed [h]") 
  # theme(legend.direction="horizontal")

ggsave("Coculturev1prop.svg",device ="svg",height = 5, width = 8)

