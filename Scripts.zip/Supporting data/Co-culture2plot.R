library("readr")

#Nanopore KMA results
a1 <- dir(paste0(dirname(rstudioapi::getSourceEditorContext()$path),"/Data/co-culture_abundancies/KMAoutput/Co-culture2/"),full.names = TRUE)



DfKMA <- data.frame()

for( i in 1:length(a1)){
  
  
  DfKMA <- rbind(DfKMA, cbind( suppressMessages(read_table(paste0(a1[i],"/1/.res"),show_col_types = FALSE)) ,basename(a1[i]),1) )
  
  a <- colnames(DfKMA)
  #im not even sure these checks are necessary
  if(!file.exists(paste0(a1[i],"/2/.res"))){
    if(exists("temp")){
      rm(temp)
    }

    next
    
  }
  #file.info(paste0(a1[i],"/2/.res"))$size 
  
  
  temp <- cbind( suppressMessages(read_table(paste0(a1[i],"/2/.res"))) ,basename(a1[i]),2)
  colnames(temp) <- a
  
  DfKMA <- rbind(DfKMA, temp)
  rm(temp)
  if(!file.exists(paste0(a1[i],"/3/.res"))){
    if(exists("temp")){
      rm(temp)
    }

    next

  }
  temp <- cbind( suppressMessages(read_table(paste0(a1[i],"/3/.res"))) ,basename(a1[i]),3)
  colnames(temp) <- a

  DfKMA <- rbind(DfKMA, temp)
  
  
  
  
  
}
realshit <- DfKMA[,c(1,9,12,13)]


colnames(realshit) <- c("Template","Depth","Sample","batch")


realshit$Meas <- 0
realshit$Strain <- 0
realshit$Exp <- 0




#Barcode to sample:


# realshit$Sample2 <- realshit$Sample

for(i in 1:length(unique(realshit$Sample))){
  
  B2 <- unlist(strsplit(unique(realshit$Sample)[i],"100_MG_"))[[2]]
  
  #Extract shit from name:
  
  B3 <- unlist(strsplit(B2,""))

  
  
  realshit$Meas[realshit$Sample == unique(realshit$Sample)[i]] <- B3[1]
  realshit$Strain[realshit$Sample == unique(realshit$Sample)[i]] <- B3[3]
  realshit$Exp[realshit$Sample == unique(realshit$Sample)[i]] <- B3[2]
  
  
}

library(ggplot2)
library(gtools)
library(RColorBrewer)

realshit$Depth <- as.numeric(realshit$Depth)

realshit$Elaps <- factor(realshit$Meas, labels = c(3, 6, 9, 12, 24, 36, 48))
realshit$Exp2 <- factor(realshit$Exp, labels = c("Constant pH 5","Constant pH 8","RC start pH 5","RC start pH 8"))
realshit$Strain2 <- factor(realshit$Strain, labels = c("CTXM15+CMYCTX","CMY2+CMYCTX","CTXM15+CMY2"))
realshit$Strain2 <- factor(realshit$Strain2 ,levels = c("CMY2+CMYCTX","CTXM15+CMY2","CTXM15+CMYCTX"))

realshit$Elaps2 <- as.numeric(as.vector(realshit$Elaps))




noshit <- data.frame()
for(i in 1:length(unique(realshit$Sample))){
  a2 <- subset(realshit,realshit$Sample == unique(realshit$Sample)[i] )
  
  
  
  #Sum depths from batch 1 and 2: 
  a3 <- data.frame()
  a4 <- data.frame()
  for(j in 1:length(unique(a2$Template))){
    a3 <- a2[a2$Template == unique(a2$Template)[j],]
    
    a4 <- rbind(a4,a3[1,])
    a4$Depth[j] <- sum(a3$Depth)
  }
  
  
  #Remove out of place reads (e.g. cmyctx in ctx+cmy culture)
  #
  #determine which template is "wrong"
    
  a5 <- unlist(strsplit(as.character(a4$Strain2[1]), "+",fixed= TRUE ))
  a4 <- a4[c( which(a4$Template %in% a5)),]
  
  a4$prop <- a4$Depth/sum(a4$Depth)
    
  # 
  if( identical(length(a4$Template), as.integer(1) )){
    #Add 0 proportion samples back (in case there was 0 reads assigned to a strain) so we can plot a 0 proportion point
    
    # a6 <- 
    a7 <- a4
    
    a7$Template <- a5[!(a5%in%a4$Template)]
    a7$prop  <- 0
    
    a4 <- rbind(a4,a7)
    rm(a7)
  } 
  
  

  noshit <- rbind(noshit,a4 )
  
}


library(ggnewscale)

PLOTCOL <- brewer.pal(8,"Set1")

fakedf <- data.frame(pH = c(rep(5,4),rep(8,4),5,8,5,8  , 8,5,8,5 ) , Exp = c(rep("A",4),rep("B",4),rep("C",4),rep("D",4) ), Elaps = rep(c(12,24,36,48),4) )

fakedf$Exp2 <- factor(fakedf$Exp, labels = c("Constant pH 5","Constant pH 8","RC start pH 5","RC start pH 8"))

fakedf$Elaps2 <- (fakedf$Elaps)

fakedf1 <- fakedf
fakedf1$Strain2 <- 1

fakedf2 <- fakedf
fakedf2$Strain2 <- 2

fakedf3 <- fakedf
fakedf3$Strain2 <- 3

fakerdf <-rbind(fakedf1, fakedf2, subset(fakedf3,!fakedf3$Exp %in% c("A","B")) ) 

fakerdf$Strain2 <- factor(fakerdf$Strain2, labels = unique(noshit$Strain2) )

#Calculate proportion so we can match it with growth data
#and add fake day 0 50/50 proportion for 


# colnames(noshit) <- c("Sample","Depth","Day","PH","Conc","PH2","Conc2","CMYprop")

# noshit$CTXprop <- 0
# noshit$CTXprop <- 1-noshit$CMYprop
# write_tsv(noshit, "Kmaresult.txt")
ggplot(subset(noshit), aes(x = (Elaps2), y = (prop),  group = interaction(Strain, Exp,Template))) +
  # # geom_point() 
  # new_scale_fill() +
  scale_x_continuous(breaks = c(0,12,24,36,48))+
  # scale_y_continuous(breaks = seq(0,1,0.25)) +
  # geom_rect( inherit.aes =FALSE, ymin = -0.05, ymax = -0.4, xmin = 0, xmax = 600, fill = NA, color = "black") +
  # geom_rect(data = fakedf, inherit.aes = FALSE, ymin = -0.05, ymax = -0.4, aes(xmin = (Elaps2)-12 ,xmax =Elaps2 ,fill = as.factor(pH) ), color = NA, alpha = 0.4) +
  geom_rect(data = fakerdf, inherit.aes = FALSE, ymin = 0, ymax = 1, aes(xmin = (Elaps2)-12 ,xmax =Elaps2 ,fill = as.factor(pH) ), color = NA, alpha = 0.3) +
  scale_fill_manual(values = c("#000000","#FFFFFF"), name = "pH") +
  # coord_cartesian(ylim = c(-0.05,1))+
  # new_scale_fill() +
  # geom_bar(stat = "identity" ,just = 1,aes(fill = Template), color = "black") +
  geom_line(aes(color =  factor(Template,levels = c("CMY2","CTXM15","CMYCTX")) ), linewidth = 1) +
  # geom_smooth(aes(color = Template), se =FALSE) +
  geom_point(data = subset(noshit,noshit$prop >0), aes(color = Template), size = 2) +
  scale_color_manual(values = PLOTCOL[c(1,2,4,3)], name = "Genes")+
  # geom_line() +
  facet_wrap(~Exp2*Strain2) +
  theme_bw() + 
  theme(
    panel.grid.minor = element_blank(),
    # panel.grid.major = element_blank()
  ) +
  ylab("Proportion [%]") +
  xlab("Time elapsed [h]") +
  theme(legend.direction = "horizontal")


source("shiftlegend2.R")

hey <- shift_legend2(last_plot())

ggsave("coculturev2prop.svg",hey,device="svg",height = 5, width = 8)
# ggsave("coculturev2prop.svg",device="svg",height = 5)

