
#Euvsec2 panels


library(readr)
library(ggplot2)
library(ggbeeswarm)
library(svglite)
library(RColorBrewer)


FOX <- c(2^seq(-1,7),-1)
ETP <- c(2^seq(-6,2),-1)
IMI <- c(2^seq(-3,5),-1)
MERO <- c(2^seq(-5,5),-1)
TAZ <- c(2^seq(-2,8),-1)
FEP <- c(2^seq(-4,6),-1)
FC <- c(2^seq(-4,7),-1)
TC <- c(2^seq(-3,8),-1)
FOT <- c(2^seq(-2,7),-1)
TRM <- c(2^seq(-1,8),-1)



#Count filamentation as growth for ctx-m-15 at pH 5: taz, fot, fep, temo
MICS <- 
  rbind( 
    data.frame( MIC = c(8,0.015,2,0.06,TAZ[11],FEP[11],0.06,0.5,FOT[10],TRM[10]), pH = c(rep(5,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(8,0.015,2,0.06,TAZ[11],FEP[11],0.06,0.5,FOT[10],TRM[10]), pH = c(rep(5,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(8,0.015,2,0.06,TAZ[11],FEP[11],0.06,0.5,FOT[10],TRM[10]), pH = c(rep(5,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(2,0.015,0.12,0.06,16,8,0.06,0.25,128,32), pH = c(rep(6,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(2,0.015,0.12,0.06,16,8,0.06,0.12,128,32), pH = c(rep(6,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(2,0.015,0.12,0.06,16,8,0.06,0.25,128,32), pH = c(rep(6,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(4,0.015,0.12,0.03,8,2,0.06,0.12,64,16), pH = c(rep(7,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(8,0.015,0.12,0.03,4,2,0.06,0.12,64,16), pH = c(rep(7,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(4,0.015,0.12,0.03,4,2,0.06,0.12,64,16), pH = c(rep(7,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(4,0.015,0.12,0.03,2,1,0.06,0.12,8,16), pH = c(rep(8,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(4,0.015,0.12,0.03,2,0.5,0.06,0.12,16,16), pH = c(rep(8,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(2,0.015,0.12,0.03,2,1,0.06,0.12,16,16), pH = c(rep(8,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(0.5,0.03,0.25,0.06,2,0.5,0.06,0.25,4,32), pH = c(rep(9,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(0.5,0.03,0.25,0.06,2,0.5,0.06,0.25,4,32), pH = c(rep(9,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(0.5,0.03,0.25,0.06,2,0.5,0.06,0.25,4,32), pH = c(rep(9,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    
    data.frame( MIC = c(16,0.015,1,0.06,1,0.12,0.06,2,0.25,32), pH = c(rep(5,10)), Strain = c("K12"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(16,0.015,2,0.06,2,0.12,0.06,1,0.25,32), pH = c(rep(5,10)), Strain = c("K12"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(16,0.015,2,0.06,2,0.12,0.06,1,0.25,32), pH = c(rep(5,10)), Strain = c("K12"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(8,0.015,0.12,0.03,0.5,0.06,0.12,0.25,0.25,32), pH = c(rep(6,10)), Strain = c("K12"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(8,0.015,0.12,0.03,0.5,0.12,0.06,0.5,0.25,32), pH = c(rep(6,10)), Strain = c("K12"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(8,0.015,0.12,0.03,0.5,0.12,0.12,0.5,0.25,32), pH = c(rep(6,10)), Strain = c("K12"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(8,0.015,0.12,0.03,0.25,0.06,0.06,0.25,0.25,8), pH = c(rep(7,10)), Strain = c("K12"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(8,0.015,0.25,0.03,0.25,0.06,0.06,0.25,0.25,8), pH = c(rep(7,10)), Strain = c("K12"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(8,0.015,0.12,0.03,0.25,0.06,0.06,0.12,0.25,16), pH = c(rep(7,10)), Strain = c("K12"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(4,0.015,0.12,0.03,0.25,0.06,0.06,0.12,0.25,8), pH = c(rep(8,10)), Strain = c("K12"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(4,0.015,0.12,0.03,0.25,0.06,0.06,0.12,0.25,8), pH = c(rep(8,10)), Strain = c("K12"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(8,0.015,0.12,0.03,0.25,0.06,0.06,0.25,0.25,16), pH = c(rep(8,10)), Strain = c("K12"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(1,0.06,0.25,0.06,0.25,0.12,0.06,0.25,0.25,32), pH = c(rep(9,10)), Strain = c("K12"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(0.5,0.06,0.25,0.06,0.25,0.12,0.06,0.25,0.25,32), pH = c(rep(9,10)), Strain = c("K12"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(1,0.12,0.25,0.06,0.25,0.12,0.06,0.25,0.25,32), pH = c(rep(9,10)), Strain = c("K12"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(16,0.03,2,0.06,4,0.25,1,4,1,128), pH = c(rep(5,10)), Strain = c("CMY-2"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(16,0.03,2,0.06,8,0.25,4,4,2,128), pH = c(rep(5,10)), Strain = c("CMY-2"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(16,0.03,4,0.06,8,0.25,2,8,2,64), pH = c(rep(5,10)), Strain = c("CMY-2"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(16,0.015,0.25,0.03,8,0.25,2,4,2,64), pH = c(rep(6,10)), Strain = c("CMY-2"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(16,0.015,0.25,0.03,8,0.5,2,4,2,64), pH = c(rep(6,10)), Strain = c("CMY-2"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(32,0.015,0.25,0.06,8,0.25,2,4,4,32), pH = c(rep(6,10)), Strain = c("CMY-2"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(16,0.015,0.12,0.03,8,0.12,2,4,2,16), pH = c(rep(7,10)), Strain = c("CMY-2"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(32,0.015,0.25,0.03,8,0.12,2,4,2,16), pH = c(rep(7,10)), Strain = c("CMY-2"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(16,0.015,0.12,0.03,8,0.25,2,4,2,16), pH = c(rep(7,10)), Strain = c("CMY-2"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(16,0.03,0.12,0.03,16,0.12,2,8,4,16), pH = c(rep(8,10)), Strain = c("CMY-2"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(32,0.06,0.12,0.03,8,0.06,4,4,2,8), pH = c(rep(8,10)), Strain = c("CMY-2"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(32,0.03,0.25,0.03,8,0.12,2,4,8,16), pH = c(rep(8,10)), Strain = c("CMY-2"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(32,0.25,1,0.06,16,0.25,8,16,8,32), pH = c(rep(9,10)), Strain = c("CMY-2"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(16,0.25,1,0.06,16,0.5,8,16,8,32), pH = c(rep(9,10)), Strain = c("CMY-2"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(16,0.12,1,0.06,16,0.5,8,32,8,32), pH = c(rep(9,10)), Strain = c("CMY-2"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(FOX[8],ETP[6],IMI[4],MERO[3],TAZ[6],FEP[8],FC[1],TC[1],FOT[6],TRM[8]), pH = c(rep(5,10)), Strain = c("A. baumannii"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[8],ETP[6],IMI[7],MERO[3],TAZ[6],FEP[8],FC[7],TC[4],FOT[6],TRM[8]), pH = c(rep(5,10)), Strain = c("A. baumannii"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[8],ETP[6],IMI[3],MERO[3],TAZ[6],FEP[8],FC[1],TC[1],FOT[6],TRM[8]), pH = c(rep(5,10)), Strain = c("A. baumannii"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[9],ETP[7],IMI[2],MERO[6],TAZ[5],FEP[7],FC[6],TC[4],FOT[6],TRM[8]), pH = c(rep(6,10)), Strain = c("A. baumannii"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[8],ETP[7],IMI[2],MERO[3],TAZ[5],FEP[6],FC[7],TC[5], FOT[7],TRM[9]), pH = c(rep(6,10)), Strain = c("A. baumannii"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[9],ETP[7],IMI[2],MERO[3],TAZ[5],FEP[7],FC[5],TC[10],FOT[7],TRM[8]), pH = c(rep(6,10)), Strain = c("A. baumannii"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[9],ETP[8],IMI[2],MERO[4],TAZ[5],FEP[6],FC[7],TC[5],FOT[6],TRM[10]), pH = c(rep(7,10)), Strain = c("A. baumannii"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[9],ETP[8],IMI[1],MERO[4],TAZ[5],FEP[6],FC[7],TC[5],FOT[6],TRM[10]), pH = c(rep(7,10)), Strain = c("A. baumannii"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[9],ETP[8],IMI[2],MERO[4],TAZ[5],FEP[7],FC[7],TC[5],FOT[6],TRM[10]), pH = c(rep(7,10)), Strain = c("A. baumannii"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[8],ETP[8],IMI[1],MERO[5],TAZ[5],FEP[6],FC[8],TC[6],FOT[6],TRM[10]), pH = c(rep(8,10)), Strain = c("A. baumannii"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[8],ETP[8],IMI[1],MERO[4],TAZ[5],FEP[6],FC[8],TC[6],FOT[7],TRM[10]), pH = c(rep(8,10)), Strain = c("A. baumannii"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[8],ETP[8],IMI[1],MERO[4],TAZ[5],FEP[6],FC[8],TC[6],FOT[7],TRM[10]), pH = c(rep(8,10)), Strain = c("A. baumannii"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[5],ETP[8],IMI[2],MERO[4],TAZ[5],FEP[7],FC[9],TC[6],FOT[4],TRM[9]), pH = c(rep(9,10)), Strain = c("A. baumannii"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[5],ETP[8],IMI[3],MERO[4],TAZ[5],FEP[7],FC[7],TC[5],FOT[6],TRM[9]), pH = c(rep(9,10)), Strain = c("A. baumannii"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[5],ETP[8],IMI[2],MERO[4],TAZ[5],FEP[7],FC[7],TC[6],FOT[6],TRM[9]), pH = c(rep(9,10)), Strain = c("A. baumannii"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(FOX[6],ETP[2],IMI[6],MERO[2],TAZ[7],FEP[11],FC[6],TC[6],FOT[10],TRM[8]), pH = c(rep(5,10)), Strain = c("CMYCTX"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[6],ETP[2],IMI[5],MERO[2],TAZ[7],FEP[11],FC[6],TC[6],FOT[10],TRM[9]), pH = c(rep(5,10)), Strain = c("CMYCTX"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[6],ETP[2],IMI[5],MERO[2],TAZ[8],FEP[11],FC[6],TC[6],FOT[10],TRM[10]), pH = c(rep(5,10)), Strain = c("CMYCTX"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[6],ETP[1],IMI[3],MERO[1],TAZ[7],FEP[9],FC[6],TC[6],FOT[10],TRM[8]), pH = c(rep(6,10)), Strain = c("CMYCTX"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[6],ETP[1],IMI[3],MERO[2],TAZ[7],FEP[8],FC[6],TC[6],FOT[10],TRM[7]), pH = c(rep(6,10)), Strain = c("CMYCTX"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[7],ETP[2],IMI[2],MERO[1],TAZ[7],FEP[10],FC[6],TC[6],FOT[10],TRM[8]), pH = c(rep(6,10)), Strain = c("CMYCTX"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[7],ETP[1],IMI[1],MERO[1],TAZ[6],FEP[6],FC[6],TC[7],FOT[10],TRM[6]), pH = c(rep(7,10)), Strain = c("CMYCTX"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[7],ETP[1],IMI[1],MERO[1],TAZ[6],FEP[6],FC[6],TC[6],FOT[8],TRM[6]), pH = c(rep(7,10)), Strain = c("CMYCTX"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[7],ETP[1],IMI[1],MERO[1],TAZ[6],FEP[6],FC[6],TC[6],FOT[9],TRM[6]), pH = c(rep(7,10)), Strain = c("CMYCTX"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[9],ETP[2],IMI[2],MERO[1],TAZ[8],FEP[5],FC[6],TC[6],FOT[8],TRM[6]), pH = c(rep(8,10)), Strain = c("CMYCTX"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[7],ETP[2],IMI[1],MERO[1],TAZ[6],FEP[5],FC[6],TC[7],FOT[7],TRM[6]), pH = c(rep(8,10)), Strain = c("CMYCTX"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[7],ETP[2],IMI[2],MERO[1],TAZ[7],FEP[5],FC[6],TC[6],FOT[7],TRM[6]), pH = c(rep(8,10)), Strain = c("CMYCTX"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[6],ETP[4],IMI[4],MERO[3],TAZ[8],FEP[4],FC[8],TC[8],FOT[6],TRM[7]), pH = c(rep(9,10)), Strain = c("CMYCTX"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[6],ETP[5],IMI[3],MERO[3],TAZ[8],FEP[5],FC[8],TC[8],FOT[6],TRM[8]), pH = c(rep(9,10)), Strain = c("CMYCTX"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[6],ETP[5],IMI[3],MERO[3],TAZ[8],FEP[4],FC[8],TC[8],FOT[7],TRM[8]), pH = c(rep(9,10)), Strain = c("CMYCTX"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(FOX[8],ETP[8],IMI[8],MERO[10],TAZ[10],FEP[10],FC[11],TC[11],FOT[9],TRM[9]), pH = c(rep(4,10)), Strain = c("Maxconc"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    # data.frame( MIC = c(FOX[9],ETP[9],IMI[9],MERO[11],TAZ[11],FEP[11],FC[12],TC[12],FOT[10],TRM[10]), pH = c(rep(6,10)), Strain = c("Maxconc"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    # data.frame( MIC = c(FOX[9],ETP[9],IMI[9],MERO[11],TAZ[11],FEP[11],FC[12],TC[12],FOT[10],TRM[10]), pH = c(rep(7,10)), Strain = c("Maxconc"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    # data.frame( MIC = c(FOX[9],ETP[9],IMI[9],MERO[11],TAZ[11],FEP[11],FC[12],TC[12],FOT[10],TRM[10]), pH = c(rep(8,10)), Strain = c("Maxconc"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[8],ETP[8],IMI[8],MERO[10],TAZ[10],FEP[10],FC[11],TC[11],FOT[9],TRM[9]), pH = c(rep(10,10)), Strain = c("Maxconc"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(FOX[1],ETP[1],IMI[1],MERO[1],TAZ[1],FEP[1],FC[1],TC[1],FOT[1],TRM[1]), pH = c(rep(4,10)), Strain = c("Minconc"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    # data.frame( MIC = c(FOX[1],ETP[1],IMI[1],MERO[1],TAZ[1],FEP[1],FC[1],TC[1],FOT[1],TRM[1]), pH = c(rep(6,10)), Strain = c("Minconc"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    # data.frame( MIC = c(FOX[1],ETP[1],IMI[1],MERO[1],TAZ[1],FEP[1],FC[1],TC[1],FOT[1],TRM[1]), pH = c(rep(7,10)), Strain = c("Minconc"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    # data.frame( MIC = c(FOX[1],ETP[1],IMI[1],MERO[1],TAZ[1],FEP[1],FC[1],TC[1],FOT[1],TRM[1]), pH = c(rep(8,10)), Strain = c("Minconc"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(FOX[1],ETP[1],IMI[1],MERO[1],TAZ[1],FEP[1],FC[1],TC[1],FOT[1],TRM[1]), pH = c(rep(10,10)), Strain = c("Minconc"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) )
    

    
  )


# PLOTCOL <- c(brewer.pal(8,"Dark2")[c(5)],brewer.pal(8,"Accent")[c(3,5,7)],brewer.pal(8,"Dark2")[c(4)])

PLOTCOL <- brewer.pal(8,"Set1")

# PLOTCOL <- PLOTCOL[c(2:4)]
MICS$antibiotic <- factor(MICS$antibiotic, levels = MICS$antibiotic[1:10] )
MICS$Strain <- as.factor(MICS$Strain)

MICS$Strain2 <- factor(MICS$Strain, levels = c("K12", "CTX-M-15", "CMY-2","CMYCTX","A. baumannii","Maxconc","Minconc"))

#MICS$antibiotic %in% c("Cefoxitin","Ceftazidime","Cefepime","Cefotaxime")

plotEUVSEC <- ggplot(subset(MICS,!(MICS$Strain %in% c("Maxconc","Minconc","A. baumannii"))) , aes( x = (pH), y = MIC,color = (Strain2)) ) +
  # geom_quasirandom(width = 0.15, size = 2, stroke = 1,aes(shape = as.factor(Strain2),  )) +
  # geom_boxplot()+
  geom_line(stat = "smooth", method = "loess", linewidth = 1.5)+
  geom_line(inherit.aes = FALSE, data = subset(MICS, MICS$Strain %in% c("Maxconc","Minconc") ), aes(x = pH, y = MIC, group = Strain2), linetype = "dashed",color = "black")+
  scale_y_log10(limits =c(0.012,300) ,breaks = round( 2^seq(-5,7,3),4) ) +
  scale_color_manual(values = PLOTCOL[ c(3,2,1,4)], name = "Strains") +
  # scale_fill_manual(values = PLOTCOL, guide = "none") +
  scale_shape_manual(values = c(0,1,2,3,4,5), name = "Strains") +
  scale_x_continuous(breaks = c(5:9))+
  xlab("Media pH") +
  ylab("Concentration [μg/ml]") +
  facet_wrap(~antibiotic) +
  theme_bw() +
  theme(axis.line = element_line(colour = "black"),
        # panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        # panel.border = element_blank(),
        panel.background = element_blank()) 
# guides(color = guide_legend(nrow = 1))
# ggtitle("CTX-M-15")
# library(ggpubr)
# source("shiftlegend2.R")

# plotEUVSEC <- as_ggplot(shift_legend2(plot1))


# ggsave("EUVSECpanel.svg",device="svg",height = 5)


#Experiments done with pH and Temperature variations 14/5/2025
MICfun <- function(x1,x2,x3,x4,x5,x6,x7,x8,x9,x10){
  
  c(FOX[x1],ETP[x2],IMI[x3],MERO[x4],TAZ[x5],FEP[x6],FC[x7],TC[x8],FOT[x9],TRM[x10])
  
}
  
  
  




MICStemp <- 
  rbind( 
    data.frame( MIC = c(FOX[6],ETP[2],IMI[4],MERO[5],TAZ[11],FEP[11],FC[2],TC[3],FOT[10],TRM[10]), pH = c(rep(5,10)), Temp = c(rep(27,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,2,4,7,11,11,2,3,10,10)), pH = c(rep(5,10)), Temp = c(rep(27,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,2,5,6,11,11,2,4,10,10)), pH = c(rep(5,10)), Temp = c(rep(27,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    # data.frame( MIC = c(MICfun(7,2,6,3,11,11,2,3,10,10)), pH = c(rep(5,10)), Temp = c(rep(35.5,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    # data.frame( MIC = c(MICfun(6,2,6,3,11,11,3,3,10,10)), pH = c(rep(5,10)), Temp = c(rep(35.5,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    # data.frame( MIC = c(MICfun(7,2,6,3,11,11,3,3,10,10)), pH = c(rep(5,10)), Temp = c(rep(35.5,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(6,2,6,3,11,11,2,4,10,10)), pH = c(rep(5,10)), Temp = c(rep(37,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,2,6,3,11,11,3,4,10,11)), pH = c(rep(5,10)), Temp = c(rep(37,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,2,6,3,11,11,2,3,10,10)), pH = c(rep(5,10)), Temp = c(rep(37,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(7,1,6,3,11,11,2,5,10,11)), pH = c(rep(5,10)), Temp = c(rep(42,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(7,2,7,3,11,11,6,4,10,10)), pH = c(rep(5,10)), Temp = c(rep(42,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(7,2,6,3,11,11,4,5,10,10)), pH = c(rep(5,10)), Temp = c(rep(42,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(3,1,1,2,5,6,1,1,8,5)), pH = c(rep(6,10)), Temp = c(rep(27,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(3,1,1,2,5,7,1,1,8,5)), pH = c(rep(6,10)), Temp = c(rep(27,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(3,1,1,2,5,7,1,1,8,5)), pH = c(rep(6,10)), Temp = c(rep(27,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    # data.frame( MIC = c(MICfun(4,1,2,2,7,11,1,2,10,7)), pH = c(rep(6,10)), Temp = c(rep(35.5,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    # data.frame( MIC = c(MICfun(5,1,2,2,7,10,1,1,10,8)), pH = c(rep(6,10)), Temp = c(rep(35.5,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    # data.frame( MIC = c(MICfun(5,1,2,2,7,11,1,2,10,11)), pH = c(rep(6,10)), Temp = c(rep(35.5,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,2,2,7,11,1,1,10,7)), pH = c(rep(6,10)), Temp = c(rep(37,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,2,2,7,11,2,2,10,11)), pH = c(rep(6,10)), Temp = c(rep(37,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,2,2,7,11,1,1,10,11)), pH = c(rep(6,10)), Temp = c(rep(37,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(6,1,3,2,7,9,2,3,10,8)), pH = c(rep(6,10)), Temp = c(rep(42,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,3,2,7,8,2,3,10,8)), pH = c(rep(6,10)), Temp = c(rep(42,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,1,3,2,7,9,2,3,10,7)), pH = c(rep(6,10)), Temp = c(rep(42,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(2,1,1,1,4,4,1,1,6,4)), pH = c(rep(7,10)), Temp = c(rep(27,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(2,1,1,1,4,4,1,1,7,4)), pH = c(rep(7,10)), Temp = c(rep(27,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(2,1,1,1,4,4,1,1,6,4)), pH = c(rep(7,10)), Temp = c(rep(27,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    # data.frame( MIC = c(MICfun(4,1,2,1,5,6,1,1,8,4)), pH = c(rep(7,10)), Temp = c(rep(35.5,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    # data.frame( MIC = c(MICfun(4,1,2,1,6,6,1,1,8,5)), pH = c(rep(7,10)), Temp = c(rep(35.5,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    # data.frame( MIC = c(MICfun(4,1,2,1,5,7,1,1,8,6)), pH = c(rep(7,10)), Temp = c(rep(35.5,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(4,1,1,1,5,7,1,1,8,11)), pH = c(rep(7,10)), Temp = c(rep(37,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(4,1,2,1,5,6,1,1,9,5)), pH = c(rep(7,10)), Temp = c(rep(37,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(4,1,2,1,5,6,1,1,8,11)), pH = c(rep(7,10)), Temp = c(rep(37,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(5,1,2,2,5,6,1,1,7,11)), pH = c(rep(7,10)), Temp = c(rep(42,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,3,1,5,6,1,1,8,6)), pH = c(rep(7,10)), Temp = c(rep(42,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,2,1,6,6,1,2,8,6)), pH = c(rep(7,10)), Temp = c(rep(42,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(2,1,2,1,4,3,1,1,6,5)), pH = c(rep(8,10)), Temp = c(rep(27,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(2,1,1,1,4,3,1,1,6,5)), pH = c(rep(8,10)), Temp = c(rep(27,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(2,1,1,1,4,3,1,1,5,4)), pH = c(rep(8,10)), Temp = c(rep(27,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    # data.frame( MIC = c(MICfun(4,1,1,1,4,5,1,1,7,6)), pH = c(rep(8,10)), Temp = c(rep(35.5,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    # data.frame( MIC = c(MICfun(5,1,1,1,4,4,1,1,7,5)), pH = c(rep(8,10)), Temp = c(rep(35.5,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    # data.frame( MIC = c(MICfun(5,1,1,1,4,4,1,1,7,5)), pH = c(rep(8,10)), Temp = c(rep(35.5,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    # 
    data.frame( MIC = c(MICfun(4,1,2,1,5,4,1,1,7,11)), pH = c(rep(8,10)), Temp = c(rep(37,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(4,1,1,1,5,5,1,1,7,5)), pH = c(rep(8,10)), Temp = c(rep(37,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(4,1,1,1,5,5,1,1,8,11)), pH = c(rep(8,10)), Temp = c(rep(37,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(4,1,2,1,4,4,1,1,5,6)), pH = c(rep(8,10)), Temp = c(rep(42,10)), Strain = c("CTX-M-15"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(4,1,3,1,3,3,1,1,4,6)), pH = c(rep(8,10)), Temp = c(rep(42,10)), Strain = c("CTX-M-15"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,2,1,3,4,1,1,5,6)), pH = c(rep(8,10)), Temp = c(rep(42,10)), Strain = c("CTX-M-15"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(5,1,5,3,2,2,1,3,1,7)), pH = c(rep(5,10)), Temp = c(rep(27,10)), Strain = c("K12"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,3,4,2,2,1,3,1,7)), pH = c(rep(5,10)), Temp = c(rep(27,10)), Strain = c("K12"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,4,4,2,2,1,3,1,7)), pH = c(rep(5,10)), Temp = c(rep(27,10)), Strain = c("K12"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    
    data.frame( MIC = c(MICfun(6,1,6,3,4,2,3,3,1,11)), pH = c(rep(5,10)), Temp = c(rep(37,10)), Strain = c("K12"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,1,6,3,4,2,2,4,1,11)), pH = c(rep(5,10)), Temp = c(rep(37,10)), Strain = c("K12"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,1,6,3,3,3,1,4,1,11)), pH = c(rep(5,10)), Temp = c(rep(37,10)), Strain = c("K12"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(6,1,7,2,4,3,1,4,1,11)), pH = c(rep(5,10)), Temp = c(rep(42,10)), Strain = c("K12"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,7,3,4,2,2,4,1,8)), pH = c(rep(5,10)), Temp = c(rep(42,10)), Strain = c("K12"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,1,7,2,4,2,2,3,1,8)), pH = c(rep(5,10)), Temp = c(rep(42,10)), Strain = c("K12"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(5,1,1,1,1,1,1,1,1,5)), pH = c(rep(6,10)), Temp = c(rep(27,10)), Strain = c("K12"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,1,1,1,1,1,1,1,5)), pH = c(rep(6,10)), Temp = c(rep(27,10)), Strain = c("K12"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,1,1,1,1,1,1,1,11)), pH = c(rep(6,10)), Temp = c(rep(27,10)), Strain = c("K12"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(5,1,1,2,3,2,1,3,1,7)), pH = c(rep(6,10)), Temp = c(rep(37,10)), Strain = c("K12"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,1,2,2,2,2,3,1,7)), pH = c(rep(6,10)), Temp = c(rep(37,10)), Strain = c("K12"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,2,2,2,2,2,2,1,11)), pH = c(rep(6,10)), Temp = c(rep(37,10)), Strain = c("K12"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(4,1,3,2,2,1,2,3,1,7)), pH = c(rep(6,10)), Temp = c(rep(42,10)), Strain = c("K12"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(4,1,1,1,2,1,2,2,1,11)), pH = c(rep(6,10)), Temp = c(rep(42,10)), Strain = c("K12"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,2,1,2,2,2,3,1,7)), pH = c(rep(6,10)), Temp = c(rep(42,10)), Strain = c("K12"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(3,1,1,1,1,1,1,1,1,3)), pH = c(rep(7,10)), Temp = c(rep(27,10)), Strain = c("K12"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(2,1,1,1,1,1,1,1,1,11)), pH = c(rep(7,10)), Temp = c(rep(27,10)), Strain = c("K12"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(3,1,1,1,1,1,1,1,1,3)), pH = c(rep(7,10)), Temp = c(rep(27,10)), Strain = c("K12"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(4,1,1,1,1,1,1,1,1,5)), pH = c(rep(7,10)), Temp = c(rep(37,10)), Strain = c("K12"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,1,1,1,1,1,1,1,11)), pH = c(rep(7,10)), Temp = c(rep(37,10)), Strain = c("K12"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,1,1,1,1,1,1,1,11)), pH = c(rep(7,10)), Temp = c(rep(37,10)), Strain = c("K12"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(5,1,2,1,1,1,1,1,1,11)), pH = c(rep(7,10)), Temp = c(rep(42,10)), Strain = c("K12"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,2,1,1,1,1,1,1,11)), pH = c(rep(7,10)), Temp = c(rep(42,10)), Strain = c("K12"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,2,1,1,1,1,2,1,11)), pH = c(rep(7,10)), Temp = c(rep(42,10)), Strain = c("K12"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(4,1,1,1,1,1,1,1,1,11)), pH = c(rep(8,10)), Temp = c(rep(27,10)), Strain = c("K12"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(3,1,1,1,1,1,1,1,1,4)), pH = c(rep(8,10)), Temp = c(rep(27,10)), Strain = c("K12"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(3,1,1,1,1,1,1,1,1,4)), pH = c(rep(8,10)), Temp = c(rep(27,10)), Strain = c("K12"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(4,1,1,1,1,1,1,1,1,11)), pH = c(rep(8,10)), Temp = c(rep(37,10)), Strain = c("K12"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,1,1,1,1,1,1,1,11)), pH = c(rep(8,10)), Temp = c(rep(37,10)), Strain = c("K12"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(4,1,1,1,1,1,1,1,1,11)), pH = c(rep(8,10)), Temp = c(rep(37,10)), Strain = c("K12"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(4,1,1,1,1,1,1,1,1,11)), pH = c(rep(8,10)), Temp = c(rep(42,10)), Strain = c("K12"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(4,1,1,1,1,1,1,1,1,5)), pH = c(rep(8,10)), Temp = c(rep(42,10)), Strain = c("K12"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,2,1,1,1,1,1,1,11)), pH = c(rep(8,10)), Temp = c(rep(42,10)), Strain = c("K12"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(8,5,4,3,5,7,1,1,5,7)), pH = c(rep(5,10)), Temp = c(rep(27,10)), Strain = c("A.baumannii"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,6,4,3,5,8,6,4,6,7)), pH = c(rep(5,10)), Temp = c(rep(27,10)), Strain = c("A.baumannii"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,6,4,3,5,7,5,3,6,7)), pH = c(rep(5,10)), Temp = c(rep(27,10)), Strain = c("A.baumannii"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),


    data.frame( MIC = c(MICfun(8,6,5,3,5,7,1,1,5,7)), pH = c(rep(5,10)), Temp = c(rep(37,10)), Strain = c("A.baumannii"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,6,6,2,5,7,1,1,5,7)), pH = c(rep(5,10)), Temp = c(rep(37,10)), Strain = c("A.baumannii"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,6,4,3,5,7,1,1,5,7)), pH = c(rep(5,10)), Temp = c(rep(37,10)), Strain = c("A.baumannii"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(7,6,6,3,6,7,1,1,6,7)), pH = c(rep(5,10)), Temp = c(rep(42,10)), Strain = c("A.baumannii"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,6,6,3,5,8,1,1,6,7)), pH = c(rep(5,10)), Temp = c(rep(42,10)), Strain = c("A.baumannii"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,6,5,3,6,8,1,1,6,8)), pH = c(rep(5,10)), Temp = c(rep(42,10)), Strain = c("A.baumannii"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(8,7,2,3,4,6,1,1,6,7)), pH = c(rep(6,10)), Temp = c(rep(27,10)), Strain = c("A.baumannii"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,7,2,3,4,6,1,1,6,7)), pH = c(rep(6,10)), Temp = c(rep(27,10)), Strain = c("A.baumannii"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,7,2,3,4,6,1,1,6,7)), pH = c(rep(6,10)), Temp = c(rep(27,10)), Strain = c("A.baumannii"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(8,7,2,3,4,6,5,1,6,7)), pH = c(rep(6,10)), Temp = c(rep(37,10)), Strain = c("A.baumannii"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,7,2,3,4,6,1,1,6,7)), pH = c(rep(6,10)), Temp = c(rep(37,10)), Strain = c("A.baumannii"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,7,2,3,4,6,6,3,6,8)), pH = c(rep(6,10)), Temp = c(rep(37,10)), Strain = c("A.baumannii"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(8,7,2,3,4,6,5,3,7,8)), pH = c(rep(6,10)), Temp = c(rep(42,10)), Strain = c("A.baumannii"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,7,3,3,5,7,6,3,6,7)), pH = c(rep(6,10)), Temp = c(rep(42,10)), Strain = c("A.baumannii"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,7,2,3,4,7,6,3,6,8)), pH = c(rep(6,10)), Temp = c(rep(42,10)), Strain = c("A.baumannii"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(8,8,2,4,5,6,8,5,7,9)), pH = c(rep(7,10)), Temp = c(rep(27,10)), Strain = c("A.baumannii"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,8,2,4,5,6,8,5,7,8)), pH = c(rep(7,10)), Temp = c(rep(27,10)), Strain = c("A.baumannii"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,8,1,4,5,6,7,4,6,8)), pH = c(rep(7,10)), Temp = c(rep(27,10)), Strain = c("A.baumannii"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(8,8,2,4,5,6,8,5,7,9)), pH = c(rep(7,10)), Temp = c(rep(37,10)), Strain = c("A.baumannii"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,7,1,4,5,6,7,4,6,9)), pH = c(rep(7,10)), Temp = c(rep(37,10)), Strain = c("A.baumannii"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(9,8,2,4,5,6,8,4,6,9)), pH = c(rep(7,10)), Temp = c(rep(37,10)), Strain = c("A.baumannii"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(8,8,1,4,5,6,7,5,6,10)), pH = c(rep(7,10)), Temp = c(rep(42,10)), Strain = c("A.baumannii"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,8,1,4,5,6,7,5,6,10)), pH = c(rep(7,10)), Temp = c(rep(42,10)), Strain = c("A.baumannii"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(9,8,1,4,5,6,7,5,6,10)), pH = c(rep(7,10)), Temp = c(rep(42,10)), Strain = c("A.baumannii"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(8,7,1,4,5,6,8,6,6,10)), pH = c(rep(8,10)), Temp = c(rep(27,10)), Strain = c("A.baumannii"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,8,1,4,5,6,8,6,7,10)), pH = c(rep(8,10)), Temp = c(rep(27,10)), Strain = c("A.baumannii"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,8,1,4,5,6,8,6,7,10)), pH = c(rep(8,10)), Temp = c(rep(27,10)), Strain = c("A.baumannii"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(8,8,1,4,5,6,9,6,6,10)), pH = c(rep(8,10)), Temp = c(rep(37,10)), Strain = c("A.baumannii"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,8,1,4,5,6,8,6,6,10)), pH = c(rep(8,10)), Temp = c(rep(37,10)), Strain = c("A.baumannii"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,8,1,4,5,5,8,6,7,10)), pH = c(rep(8,10)), Temp = c(rep(37,10)), Strain = c("A.baumannii"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(8,7,1,4,5,5,7,6,6,10)), pH = c(rep(8,10)), Temp = c(rep(42,10)), Strain = c("A.baumannii"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,8,1,4,5,5,8,6,6,10)), pH = c(rep(8,10)), Temp = c(rep(42,10)), Strain = c("A.baumannii"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,8,1,4,5,5,9,5,6,10)), pH = c(rep(8,10)), Temp = c(rep(42,10)), Strain = c("A.baumannii"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    
    data.frame( MIC = c(MICfun(6,1,5,5,6,7,4,4,8,7)), pH = c(rep(5,10)), Temp = c(rep(27,10)), Strain = c("CMYCTX"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,3,3,5,6,4,4,7,6)), pH = c(rep(5,10)), Temp = c(rep(27,10)), Strain = c("CMYCTX"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,5,5,6,6,5,4,8,7)), pH = c(rep(5,10)), Temp = c(rep(27,10)), Strain = c("CMYCTX"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),


    data.frame( MIC = c(MICfun(5,2,7,3,7,9,6,6,10,7)), pH = c(rep(5,10)), Temp = c(rep(37,10)), Strain = c("CMYCTX"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,2,5,3,8,9,6,6,10,7)), pH = c(rep(5,10)), Temp = c(rep(37,10)), Strain = c("CMYCTX"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,2,6,3,7,10,6,6,9,7)), pH = c(rep(5,10)), Temp = c(rep(37,10)), Strain = c("CMYCTX"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(6,2,6,2,7,9,6,6,10,9)), pH = c(rep(5,10)), Temp = c(rep(42,10)), Strain = c("CMYCTX"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,2,8,3,7,8,6,6,10,8)), pH = c(rep(5,10)), Temp = c(rep(42,10)), Strain = c("CMYCTX"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,2,7,3,8,11,6,7,10,8)), pH = c(rep(5,10)), Temp = c(rep(42,10)), Strain = c("CMYCTX"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(7,1,1,1,6,7,4,4,8,5)), pH = c(rep(6,10)), Temp = c(rep(27,10)), Strain = c("CMYCTX"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,1,1,1,5,6,4,4,7,5)), pH = c(rep(6,10)), Temp = c(rep(27,10)), Strain = c("CMYCTX"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(7,1,1,1,6,6,4,4,8,5)), pH = c(rep(6,10)), Temp = c(rep(27,10)), Strain = c("CMYCTX"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(7,1,2,2,7,9,6,6,10,5)), pH = c(rep(6,10)), Temp = c(rep(37,10)), Strain = c("CMYCTX"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,1,2,2,6,8,5,6,10,5)), pH = c(rep(6,10)), Temp = c(rep(37,10)), Strain = c("CMYCTX"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,2,2,2,6,9,5,6,10,5)), pH = c(rep(6,10)), Temp = c(rep(37,10)), Strain = c("CMYCTX"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(6,2,3,2,8,9,7,7,10,6)), pH = c(rep(6,10)), Temp = c(rep(42,10)), Strain = c("CMYCTX"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(7,1,3,2,7,9,7,7,10,7)), pH = c(rep(6,10)), Temp = c(rep(42,10)), Strain = c("CMYCTX"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,2,3,2,7,9,7,7,10,7)), pH = c(rep(6,10)), Temp = c(rep(42,10)), Strain = c("CMYCTX"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(7,1,1,1,4,4,5,5,6,4)), pH = c(rep(7,10)), Temp = c(rep(27,10)), Strain = c("CMYCTX"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(7,1,1,1,4,4,4,4,6,4)), pH = c(rep(7,10)), Temp = c(rep(27,10)), Strain = c("CMYCTX"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(7,1,1,1,5,4,5,5,7,4)), pH = c(rep(7,10)), Temp = c(rep(27,10)), Strain = c("CMYCTX"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(7,1,2,2,7,7,6,7,10,6)), pH = c(rep(7,10)), Temp = c(rep(37,10)), Strain = c("CMYCTX"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(7,1,2,1,7,7,6,7,9,5)), pH = c(rep(7,10)), Temp = c(rep(37,10)), Strain = c("CMYCTX"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(7,1,2,1,7,6,6,8,10,6)), pH = c(rep(7,10)), Temp = c(rep(37,10)), Strain = c("CMYCTX"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(7,2,2,1,7,7,7,7,9,5)), pH = c(rep(7,10)), Temp = c(rep(42,10)), Strain = c("CMYCTX"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(8,1,2,1,7,6,7,7,8,5)), pH = c(rep(7,10)), Temp = c(rep(42,10)), Strain = c("CMYCTX"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(7,1,1,1,8,7,7,7,10,6)), pH = c(rep(7,10)), Temp = c(rep(42,10)), Strain = c("CMYCTX"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(7,1,1,1,5,3,5,5,6,4)), pH = c(rep(8,10)), Temp = c(rep(27,10)), Strain = c("CMYCTX"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(7,2,1,1,5,4,5,5,5,4)), pH = c(rep(8,10)), Temp = c(rep(27,10)), Strain = c("CMYCTX"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,1,1,4,2,5,5,6,4)), pH = c(rep(8,10)), Temp = c(rep(27,10)), Strain = c("CMYCTX"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(8,2,2,1,6,4,6,7,7,5)), pH = c(rep(8,10)), Temp = c(rep(37,10)), Strain = c("CMYCTX"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(7,2,1,1,7,5,6,6,7,6)), pH = c(rep(8,10)), Temp = c(rep(37,10)), Strain = c("CMYCTX"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(7,2,2,1,7,5,6,7,7,6)), pH = c(rep(8,10)), Temp = c(rep(37,10)), Strain = c("CMYCTX"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(7,2,2,1,7,5,7,7,7,5)), pH = c(rep(8,10)), Temp = c(rep(42,10)), Strain = c("CMYCTX"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(7,3,2,1,7,5,7,7,7,5)), pH = c(rep(8,10)), Temp = c(rep(42,10)), Strain = c("CMYCTX"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(7,2,2,1,7,6,7,7,7,5)), pH = c(rep(8,10)), Temp = c(rep(42,10)), Strain = c("CMYCTX"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    
    data.frame( MIC = c(MICfun(4,1,3,3,3,1,3,3,2,5)), pH = c(rep(5,10)), Temp = c(rep(27,10)), Strain = c("CMY-2"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(4,1,3,3,3,1,4,4,2,5)), pH = c(rep(5,10)), Temp = c(rep(27,10)), Strain = c("CMY-2"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(4,1,3,3,3,1,4,4,2,5)), pH = c(rep(5,10)), Temp = c(rep(27,10)), Strain = c("CMY-2"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(6,1,5,3,5,3,5,6,4,7)), pH = c(rep(5,10)), Temp = c(rep(37,10)), Strain = c("CMY-2"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,2,6,3,5,3,5,6,4,7)), pH = c(rep(5,10)), Temp = c(rep(37,10)), Strain = c("CMY-2"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,1,6,3,6,3,5,6,4,7)), pH = c(rep(5,10)), Temp = c(rep(37,10)), Strain = c("CMY-2"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(6,1,7,2,6,3,5,6,4,8)), pH = c(rep(5,10)), Temp = c(rep(42,10)), Strain = c("CMY-2"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,8,3,6,3,5,6,4,8)), pH = c(rep(5,10)), Temp = c(rep(42,10)), Strain = c("CMY-2"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,1,7,2,6,3,6,6,5,8)), pH = c(rep(5,10)), Temp = c(rep(42,10)), Strain = c("CMY-2"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(5,1,1,1,4,1,4,3,3,4)), pH = c(rep(6,10)), Temp = c(rep(27,10)), Strain = c("CMY-2"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,1,1,3,1,4,3,2,4)), pH = c(rep(6,10)), Temp = c(rep(27,10)), Strain = c("CMY-2"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,1,1,3,1,4,3,2,4)), pH = c(rep(6,10)), Temp = c(rep(27,10)), Strain = c("CMY-2"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(6,1,2,1,6,2,5,5,5,5)), pH = c(rep(6,10)), Temp = c(rep(37,10)), Strain = c("CMY-2"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,1,2,2,6,2,5,6,4,5)), pH = c(rep(6,10)), Temp = c(rep(37,10)), Strain = c("CMY-2"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,1,2,2,6,2,6,6,4,5)), pH = c(rep(6,10)), Temp = c(rep(37,10)), Strain = c("CMY-2"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(7,1,2,2,6,3,6,6,5,6)), pH = c(rep(6,10)), Temp = c(rep(42,10)), Strain = c("CMY-2"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,1,2,1,6,3,6,6,5,6)), pH = c(rep(6,10)), Temp = c(rep(42,10)), Strain = c("CMY-2"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,1,3,2,6,3,6,6,5,6)), pH = c(rep(6,10)), Temp = c(rep(42,10)), Strain = c("CMY-2"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(5,1,1,1,3,1,3,3,2,3)), pH = c(rep(7,10)), Temp = c(rep(27,10)), Strain = c("CMY-2"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,1,1,3,1,4,4,2,3)), pH = c(rep(7,10)), Temp = c(rep(27,10)), Strain = c("CMY-2"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,1,1,3,1,4,3,2,3)), pH = c(rep(7,10)), Temp = c(rep(27,10)), Strain = c("CMY-2"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(6,1,1,1,6,1,5,4,4,4)), pH = c(rep(7,10)), Temp = c(rep(37,10)), Strain = c("CMY-2"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,1,1,1,6,1,5,5,4,4)), pH = c(rep(7,10)), Temp = c(rep(37,10)), Strain = c("CMY-2"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,1,2,1,5,2,6,5,4,5)), pH = c(rep(7,10)), Temp = c(rep(37,10)), Strain = c("CMY-2"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(6,1,2,1,6,2,6,6,5,5)), pH = c(rep(7,10)), Temp = c(rep(42,10)), Strain = c("CMY-2"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,1,2,1,6,2,6,6,5,5)), pH = c(rep(7,10)), Temp = c(rep(42,10)), Strain = c("CMY-2"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,1,2,1,6,2,6,6,5,6)), pH = c(rep(7,10)), Temp = c(rep(42,10)), Strain = c("CMY-2"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(5,1,1,1,4,1,4,2,3,4)), pH = c(rep(8,10)), Temp = c(rep(27,10)), Strain = c("CMY-2"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,1,1,4,1,3,3,2,3)), pH = c(rep(8,10)), Temp = c(rep(27,10)), Strain = c("CMY-2"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(5,1,1,1,4,1,4,3,3,3)), pH = c(rep(8,10)), Temp = c(rep(27,10)), Strain = c("CMY-2"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(6,1,1,1,6,1,5,5,5,5)), pH = c(rep(8,10)), Temp = c(rep(37,10)), Strain = c("CMY-2"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(7,2,1,1,6,1,6,5,5,5)), pH = c(rep(8,10)), Temp = c(rep(37,10)), Strain = c("CMY-2"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,1,2,1,5,2,5,5,5,5)), pH = c(rep(8,10)), Temp = c(rep(37,10)), Strain = c("CMY-2"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),

    data.frame( MIC = c(MICfun(6,2,2,1,6,1,6,6,5,5)), pH = c(rep(8,10)), Temp = c(rep(42,10)), Strain = c("CMY-2"), Biorep = c(rep(1,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,2,1,1,6,2,5,5,5,5)), pH = c(rep(8,10)), Temp = c(rep(42,10)), Strain = c("CMY-2"), Biorep = c(rep(2,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) ),
    data.frame( MIC = c(MICfun(6,2,3,1,6,1,6,5,5,5)), pH = c(rep(8,10)), Temp = c(rep(42,10)), Strain = c("CMY-2"), Biorep = c(rep(3,10)), antibiotic = c("Cefoxitin","Ertapenem","Imipenem","Meropenem","Ceftazidime","Cefepime","Cefotaxime+clav","Ceftazidime +clav", "Cefotaxime","Temocillin" ) )

    
    
 )
  
MICStemp$Strain2 <- factor(MICStemp$Strain, levels = c("K12", "CTX-M-15", "CMY-2","CMYCTX","A. baumannii","Maxconc","Minconc"))

# test1 <- subset(MICS, MICS$Strain2 == "CTX-M-15")
# test2 <- subset(MICS, MICS$Strain2 %in% c("Maxconc","Minconc"))
# 
# 
# test2$Temp <- 37
# test1$Temp <- 37

# ggplot(subset(MICStemp, MICStemp$MIC > 0 & MICStemp$Strain == "CMY-2"), aes(x = pH, y = MIC, color = as.factor(Temp), linetype = as.factor(Strain) )) +
#   # geom_point() +
#   # geom_beeswarm() +
#   facet_wrap(~antibiotic) +
#   geom_smooth(se=FALSE) +
#   # geom_smooth(data = test1,linetype ="dashed", se=FALSE, color = "black") +
#   # geom_beeswarm(data = test1, color = "black") +
#   # geom_line(data = test2, aes(x = pH, y = MIC, group = Strain2), linetype = "dashed",color = "black")+
#   # scale_color_manual(values = PLOTCOL) +
#   theme_bw() +
#   scale_y_continuous(trans = "log2", breaks = 2^seq(-5,10)) +
#   coord_cartesian(xlim = c(5,8))
# 
# 
# 
# ggsave("EUVSECtempmicph.svg",device="svg",limitsize = FALSE, width = 10)
# 
# setwd("C:/Users/mikkan/OneDrive - Danmarks Tekniske Universitet/Dokumenter/micpanels/temp/")


pllot1 <- ggplot(subset(MICStemp, MICStemp$antibiotic == "Ceftazidime" & MICStemp$Strain2 %in% c("CTX-M-15","CMY-2")), aes(x = pH, y = MIC, color = as.factor(Strain), linetype = as.factor(Temp) )) +
  # geom_point() +
  # geom_beeswarm() +
  # facet_wrap(~) +
  geom_smooth(se=FALSE) +
  scale_color_manual(values = PLOTCOL[c(1,2)], name = "Strain") +
  scale_linetype_manual(name = "Temperature",values = c("27" = "dotted","37" = "solid","42" = "dashed"), labels = c("27°C","37°C","42°C"))+ 
  # geom_smooth(data = test1,linetype ="dashed", se=FALSE, color = "black") +
  # geom_beeswarm(data = test1, color = "black") +
  # geom_line(data = test2, aes(x = pH, y = MIC, group = Strain), linetype = "dashed",color = "black")+
  geom_hline(yintercept = 128, linetype = "dashed",color = "black")+
  geom_hline(yintercept = 0.25, linetype = "dashed",color = "black")+
  theme_bw() +
  scale_y_continuous(trans = "log2", breaks = 2^seq(-5,7)) +
  coord_cartesian(xlim = c(5,8))

pllot2 <- ggplot(subset(MICStemp, MICStemp$antibiotic == "Cefotaxime" & MICStemp$Strain2 %in% c("CTX-M-15","CMY-2")), aes(x = pH, y = MIC, color = as.factor(Strain), linetype = as.factor(Temp) )) +
  # geom_point() +
  # geom_beeswarm() +
  # facet_wrap(~) +
  geom_smooth(se=FALSE) +
  scale_color_manual(values = PLOTCOL[c(1,2)], name = "Strain") +
  scale_linetype_manual(name = "Temperature",values = c("27" = "dotted","37" = "solid","42" = "dashed"), labels = c("27°C","37°C","42°C"))+ 
  # geom_smooth(data = test1,linetype ="dashed", se=FALSE, color = "black") +
  # geom_beeswarm(data = test1, color = "black") +
  # geom_line(data = test2, aes(x = pH, y = MIC, group = Strain), linetype = "dashed",color = "black")+
  geom_hline(yintercept = 64, linetype = "dashed",color = "black")+
  geom_hline(yintercept = 0.25, linetype = "dashed",color = "black")+
  theme_bw() +
  scale_y_continuous(trans = "log2", breaks = 2^seq(-5,6)) +
  coord_cartesian(xlim = c(5,8))

ggarrange(pllot1, pllot2, nrow = 1, labels = c("A","B"), common.legend = TRUE, legend = "right")

ggsave("TEMPpHMICplot.svg",limitsize = FALSE, device = "svg",width = 10)
# 


