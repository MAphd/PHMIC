library(readr) 
HERE <- dirname(rstudioapi::getSourceEditorContext()$path)

Outdir <- paste0(HERE,"/Data/Molecular_modeling/docking/vinaOutput/")

Angdistcmy <- function(x, y, z){
  
  #Serine 64 relevant "O" (ketone) group position: -10.559  44.043  30.005 in 1zc2
  
  sqrt( (-10.559-x)^2 + (44.043-y)^2 + (30.005 -z)^2 )
}

Angdistctx <- function(x, y, z){
  
  #Catalytic serine (70) position of ketone
  sqrt( (-6.350-x)^2 + (-3.530-y)^2 + (15.011 -z)^2 )
  
}

#Results sumup:
Resfil <- list.files((Outdir), pattern = "_vinaout.txt")

Finaldata <- data.frame()
for(i in (Resfil)){
  dftemp <- data.frame( read_table(paste0((Outdir),i), 
                                   col_names = FALSE, skip = 38) )
  
  
  # Grab xyz of relevant keton in beta-lactam - atom 30 in ceftazidime, find like in FOT
  
  # Atom 9 in cefotaxime
  Tempc1 <- unlist(strsplit(i,"_"))
  
  dftemp$Receptor <- Tempc1[1]
  # dftemp$pH <- Tempc1[2]
  # dftemp$Ligand <- paste0(Tempc1[3],Tempc1[4])
  dftemp$pH <- Tempc1[3]
  dftemp$Ligand <- Tempc1[2]
  
  Vinamods <- read_csv(paste0(Outdir,strsplit(i, ".txt",fixed= TRUE),".pdbqt"), 
                       col_names = FALSE)
  
  
  if(grepl("1zc2",dftemp$Receptor[1]) ){
    if(grepl("fot",dftemp$Ligand[1], ignore.case = TRUE)){
      
      
      #Get coordinates of relevant ketone in catalytic serine
      Atoms1 <- Vinamods[which(apply(Vinamods, 1, function(x) grepl("ATOM      9",x) )),]
      Atoms2 <- apply(Atoms1, 1, function(x) cbind(unlist(strsplit(x,"ATOM      9  O   UNL     1      ",fixed = TRUE))[2] ))
      Atoms3 <- lapply(Atoms2, function(x) strsplit(unlist(strsplit(x, "  1.00  0.00    ",fixed = TRUE))[c(TRUE,FALSE)],"  ",fixed=TRUE)     )
      Coords <- t(as.matrix(sapply(Atoms3, function(x) unlist((x)))))
      
      dftemp$Dist1 <- Angdistcmy(as.numeric(Coords[,1]),as.numeric(Coords[,2]),as.numeric(Coords[,3]))
      
      
    } else if(grepl("taz",dftemp$Ligand[1], ignore.case = TRUE)){
      
      #Get coordinates of relevant ketone in catalytic serine
      Atoms1 <- Vinamods[which(apply(Vinamods, 1, function(x) grepl("ATOM     30",x) )),]
      Atoms2 <- apply(Atoms1, 1, function(x) cbind(unlist(strsplit(x,"ATOM     30  O   UNL     1      ",fixed = TRUE))[2] ))
      Atoms3 <- lapply(Atoms2, function(x) strsplit(unlist(strsplit(x, "  1.00  0.00    ",fixed = TRUE))[c(TRUE,FALSE)],"  ",fixed=TRUE)     )
      Coords <- t(as.matrix(sapply(Atoms3, function(x) unlist((x)))))
      
      dftemp$Dist1 <- Angdistcmy(as.numeric(Coords[,1]),as.numeric(Coords[,2]),as.numeric(Coords[,3]))
      
    } else if(grepl("nit",dftemp$Ligand[1], ignore.case = TRUE)){
      
      #Get coordinates of relevant ketone in catalytic serine
      Atoms1 <- Vinamods[which(apply(Vinamods, 1, function(x) grepl("ATOM     10",x) )),]
      Atoms2 <- apply(Atoms1, 1, function(x) cbind(unlist(strsplit(x,"ATOM     10  O   UNL     1      ",fixed = TRUE))[2] ))
      Atoms3 <- lapply(Atoms2, function(x) strsplit(unlist(strsplit(x, "  1.00  0.00    ",fixed = TRUE))[c(TRUE,FALSE)],"  ",fixed=TRUE)     )
      Coords <- t(as.matrix(sapply(Atoms3, function(x) unlist((x)))))
      
      dftemp$Dist1 <- Angdistcmy(as.numeric(Coords[,1]),as.numeric(Coords[,2]),as.numeric(Coords[,3]))
      
    }
    
    
    
  } else if(grepl("4hbt",dftemp$Receptor[1])){
    
    
    if(grepl("fot",dftemp$Ligand[1], ignore.case = TRUE)){
      
      
      #Get coordinates of relevant ketone in catalytic serine
      Atoms1 <- Vinamods[which(apply(Vinamods, 1, function(x) grepl("ATOM      9",x) )),]
      Atoms2 <- apply(Atoms1, 1, function(x) cbind(unlist(strsplit(x,"ATOM      9  O   UNL     1      ",fixed = TRUE))[2] ))
      Atoms3 <- lapply(Atoms2, function(x) strsplit(unlist(strsplit(x, "  1.00  0.00    ",fixed = TRUE))[c(TRUE,FALSE)],"  ",fixed=TRUE)     )
      Coords <- t(as.matrix(sapply(Atoms3, function(x) unlist((x)))))
      
      dftemp$Dist1 <- Angdistctx(as.numeric(Coords[,1]),as.numeric(Coords[,2]),as.numeric(Coords[,3]))
      
      
    } else if(grepl("taz",dftemp$Ligand[1], ignore.case = TRUE)){
      
      #Get coordinates of relevant ketone in catalytic serine
      Atoms1 <- Vinamods[which(apply(Vinamods, 1, function(x) grepl("ATOM     30",x) )),]
      Atoms2 <- apply(Atoms1, 1, function(x) cbind(unlist(strsplit(x,"ATOM     30  O   UNL     1      ",fixed = TRUE))[2] ))
      Atoms3 <- lapply(Atoms2, function(x) strsplit(unlist(strsplit(x, "  1.00  0.00    ",fixed = TRUE))[c(TRUE,FALSE)],"  ",fixed=TRUE)     )
      Coords <- t(as.matrix(sapply(Atoms3, function(x) unlist((x)))))
      
      dftemp$Dist1 <- Angdistctx(as.numeric(Coords[,1]),as.numeric(Coords[,2]),as.numeric(Coords[,3]))
      
    }else if(grepl("nit",dftemp$Ligand[1], ignore.case = TRUE)){
      
      #Get coordinates of relevant ketone in catalytic serine
      Atoms1 <- Vinamods[which(apply(Vinamods, 1, function(x) grepl("ATOM     10",x) )),]
      Atoms2 <- apply(Atoms1, 1, function(x) cbind(unlist(strsplit(x,"ATOM     10  O   UNL     1      ",fixed = TRUE))[2] ))
      Atoms3 <- lapply(Atoms2, function(x) strsplit(unlist(strsplit(x, "  1.00  0.00    ",fixed = TRUE))[c(TRUE,FALSE)],"  ",fixed=TRUE)     )
      Coords <- t(as.matrix(sapply(Atoms3, function(x) unlist((x)))))
      
      dftemp$Dist1 <- Angdistctx(as.numeric(Coords[,1]),as.numeric(Coords[,2]),as.numeric(Coords[,3]))
      
    }
    
    
    
    
  }
  
  
  # Modindex <- which(apply(Vinamods, 1, function(x) grepl("MODEL",x) ))
  
  # Vinamods[which(apply(Vinamods, 1, function(x) grepl("ATOM     30",x) )),]
  # 
  # Vinamods[which(apply(Vinamods, 1, function(x) grepl("ATOM      9",x) )),]
  
  
  
  
  
  
  
  
  
  Finaldata <- rbind(Finaldata, dftemp)
  
}
colnames(Finaldata) <- c("Mode","Affinity","Dist from rmsd l.b.","Best mode rmsd u.b.","Receptor","pH","Ligand","Dist")



library(ggplot2)



#Atom serial_number=30 is the relevant oxygen in the beta-lactam

# library(ggbeeswarm)
library(ggpubr)
Finaldata$pH2 <- as.numeric(unlist(strsplit(Finaldata$pH,"ph"))[c(FALSE,TRUE)])

# compares <- list(c("1zc2mono","4hbt"))
# 
# ggplot(subset(Finaldata), aes(x = Receptor, y = Affinity )) +
#   # geom_violin(aes(fill= Receptor)) +
#   # geom_point(aes(color = Receptor)) +
#   geom_boxplot(aes(fill = Receptor)) +
#   # geom_quasirandom(aes(color = Receptor)) +
#   stat_compare_means(comparisons = compares, method = "t.test", aes(label = "p.signif"))+
#   facet_wrap(~pH*Ligand) +
#   theme_bw() +
#   ylab("Affinity [kcal/mol]") +
#   xlab("pH")
# 
plot1 <- ggplot(subset(Finaldata), aes(x = as.factor(pH2), y = Affinity )) +
  # geom_violin(aes(fill= Receptor)) +
  # geom_point(aes(color = Receptor)) +
  geom_boxplot(aes(fill = Receptor)) +
  # geom_quasirandom(aes(color = Receptor)) +
  # stat_compare_means(comparisons = compares, method = "t.test")+
  facet_wrap(~Ligand) +
  theme_bw() +
  ylab("Affinity [kcal/mol]") +
  xlab("pH")


plot2 <- ggplot(subset(Finaldata), aes(x = as.factor(pH2), y = Dist )) +
  # geom_violin(aes(fill= Receptor)) +
  # geom_point(aes(color = Receptor)) +
  geom_boxplot(aes(fill = Receptor)) +
  # geom_quasirandom(aes(color = Receptor)) +
  facet_wrap(~Ligand) +
  theme_bw() +
  ylab("Distance [Å]") +
  xlab("pH")

# ggplot(Finaldata, aes(x = Affinity, y = Dist, color = Receptor)) +
#   geom_point() +
#   facet_wrap(~Ligand)


ggarrange(plot1, plot2, ncol = 2, labels =c("A","B"), common.legend = TRUE, legend = "bottom")

ggsave("moldock.svg",device= "svg",width = 10)

