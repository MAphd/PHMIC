library("readr")




a1 <- dir(paste0(dirname(rstudioapi::getSourceEditorContext()$path),"/Data/co-culture_abundancies/KMAoutput/Co-culture3/"),full.names = TRUE, pattern = ".res")



DfKMA <- data.frame()

for( i in 1:length(a1)){
  
  
  DfKMA <- rbind(DfKMA, cbind( suppressMessages(read_table(paste0(a1[i]),show_col_types = FALSE)) ,basename(a1[i])) )
  
  a <- colnames(DfKMA)

  
}
realshit <- DfKMA[,c(1,9,12)]


colnames(realshit) <- c("Template","Depth","Sample")


realshit$Meas <- 0
realshit$Strain <- 0
realshit$Exp <- 0




for(i in 1:length(unique(realshit$Sample))){
  
  B2 <- unlist(strsplit(unique(realshit$Sample)[i],"100_MG_"))[[2]]
  
  #Extract from name:
  
  B3 <- unlist(strsplit(B2,""))

  
  
  realshit$Meas[realshit$Sample == unique(realshit$Sample)[i]] <- B3[1]
  realshit$Strain[realshit$Sample == unique(realshit$Sample)[i]] <- B3[3]
  realshit$Exp[realshit$Sample == unique(realshit$Sample)[i]] <- B3[2]
  
  
}

library(ggplot2)

library(gtools)
library(RColorBrewer)

realshit$Depth <- as.numeric(realshit$Depth)

realshit$Elaps <- factor(realshit$Meas, labels = c(3, 6, 9, 12))
realshit$Exp2 <- factor(realshit$Exp, labels = c("Constant pH 5","Constant pH 8","RC start pH 5","RC start pH 8"))
realshit$Strain2 <- factor(realshit$Strain, labels = c("CTXM15+CMYCTX","CMY2+CMYCTX","CTXM15+CMY2"))
realshit$Strain2 <- factor(realshit$Strain2 ,levels = c("CMY2+CMYCTX","CTXM15+CMY2","CTXM15+CMYCTX"))

realshit$Elaps2 <- as.numeric(as.vector(realshit$Elaps))




noshit <- data.frame()
for(i in 1:length(unique(realshit$Sample))){
  a2 <- subset(realshit,realshit$Sample == unique(realshit$Sample)[i] )
  
  
  #determine which template is "wrong"
 # a4 <- data.frame()  
  a5 <- unlist(strsplit(as.character(a2$Strain2[1]), "+",fixed= TRUE ))
  a2 <- a2[c( which(a2$Template %in% a5)),]
  
  a2$prop <- a2$Depth/sum(a2$Depth)
    
  # 
  if( identical(length(a2$Template), as.integer(1) )){
    #Add 0 proportion samples back (in case there was 0 reads assigned to a strain) so we can plot a 0 proportion point
    
    a7 <- a2
    
    a7$Template <- a5[!(a5%in%a2$Template)]
    a7$prop  <- 0
    
    a2 <- rbind(a2,a7)
    rm(a7)
  } 
  
  

  noshit <- rbind(noshit,a2 )
  
}


library(ggnewscale)

PLOTCOL <- brewer.pal(8,"Set1")

fakedf <- data.frame(pH = c(rep(5,4),rep(8,4),5,8,5,8  , 8,5,8,5 ) , Exp = c(rep("A",4),rep("B",4),rep("C",4),rep("D",4) ), Elaps = rep(c(0,3,6,9),4) )

fakedf$Exp2 <- factor(fakedf$Exp, labels = c("Constant pH 5","Constant pH 8","RC start pH 5","RC start pH 8"))

fakedf$Elaps2 <- (fakedf$Elaps)




fakedf1 <- fakedf
fakedf1$Strain2 <- 1

fakedf2 <- fakedf
fakedf2$Strain2 <- 2

fakedf3 <- fakedf
fakedf3$Strain2 <- 3

fakerdf <-rbind(fakedf1, fakedf2, subset(fakedf3,!fakedf3$Exp %in% c("A","B")) ) 

fakerdf$Strain2 <- factor(fakerdf$Strain2, labels = unique(noshit$Strain2) )

#Calculate proportion so we can match it with growth data
#and add fake day 0 50/50 proportion for all
noshit2 <- data.frame()
#noshit fake elapsed 0 50/50 proportion data:
for(i in 1:length(unique(noshit$Strain))){
  tempshit1 <- subset(noshit, noshit$Strain == unique(noshit$Strain)[i])
  for(j in 1:length(unique(tempshit1$Exp))){
  tempshit2 <- subset(tempshit1, tempshit1$Exp == unique(tempshit1$Exp)[j])
  
  A <- unique(tempshit2$Template)
  
  
  
  
  noshit2 <- rbind(noshit2, data.frame(Template = A, Depth = 0, Sample = "fake", Meas = 0,Strain = tempshit2$Strain[1],Exp = tempshit2$Exp[1],Elaps = 0, 
             Exp2 = tempshit2$Exp2[1],Strain2 = tempshit2$Strain2[1], Elaps2 = 0, prop = 0.5))
  
  
  }
}

noshit$Elaps <- as.numeric(as.vector(noshit$Elaps))


noshit <- rbind(noshit,noshit2)

noshit$Elaps <- as.factor(noshit$Elaps)
# colnames(noshit) <- c("Sample","Depth","Day","PH","Conc","PH2","Conc2","CMYprop")

# noshit$CTXprop <- 0
# noshit$CTXprop <- 1-noshit$CMYprop
# write_tsv(noshit, "Kmaresult.txt")
rm(noshit2)

# noshit$Facetval <- interaction(noshit$Exp2, noshit$Strain2)
# 
# noshit$Facetval <- factor(noshit$Facetval, labels = c("Constant pH 5","Constant pH 8","RC start pH 5","RC start pH 8","RC start pH 5","RC start pH 8","Constant pH 5","Constant pH 8",
#                                                       "RC start pH 5","RC start pH 8") )
# 
# fakerdf$Facetval <- interaction(fakerdf$Exp2, fakerdf$Strain2)

ggplot(subset(noshit), aes(x = (Elaps2), y = (prop),  group = interaction(Strain, Exp,Template))) +
  # # geom_point() 
  # new_scale_fill() +
  scale_x_continuous(breaks = c(0,3,6,9,12))+
  # scale_y_continuous(breaks = seq(0,1,0.25)) +
  # geom_rect( inherit.aes =FALSE, ymin = -0.05, ymax = -0.4, xmin = 0, xmax = 600, fill = NA, color = "black") +
  # geom_rect(data = fakedf, inherit.aes = FALSE, ymin = -0.05, ymax = -0.4, aes(xmin = (Elaps2)+3 ,xmax =Elaps2 ,fill = as.factor(pH) ), color = NA, alpha = 0.4) +
  geom_rect(data = fakerdf, inherit.aes = FALSE, ymin = 0, ymax = 1, aes(xmin = (Elaps2)+3 ,xmax =Elaps2 ,fill = as.factor(pH), group = interaction(Strain2, Exp2 ) ), color = NA, alpha = 0.3) +
  scale_fill_manual(values = c("#000000","#FFFFFF"), name = "pH") +
  # coord_cartesian(xlim = c(3,12))+
  # new_scale_fill() +
  # geom_bar(stat = "identity" ,just = 1,aes(fill = Template), color = "black") +
  geom_line(aes(color = factor(Template,levels = c("CMY2","CTXM15","CMYCTX")) ), linewidth = 1) +
  # geom_smooth(aes(color = Template), se =FALSE) +
  geom_point(data = subset(noshit,noshit$prop >0 & noshit$Depth > 0), aes(color = Template), size = 2) +
  scale_color_manual(values = PLOTCOL[c(1,2,4,1)], name = "Genes")+
  # geom_line() +
  # facet_wrap(~Exp2*Strain2) #, labeller = labeller(Strain2 = function(x) {rep("", length(x))}) ) +
  facet_wrap(~Exp2*Strain2)+
  theme_bw() + 
  theme(
    panel.grid.minor = element_blank(),
    # panel.grid.major = element_blank()
  ) +
  ylab("Proportion [%]") +
  xlab("Time elapsed [h]") +
  theme(legend.direction="horizontal")

source("shiftlegend2.R")

hey <- shift_legend2(last_plot())

ggsave("coculturev3prop.svg",hey,device="svg",height = 5, width = 8)

