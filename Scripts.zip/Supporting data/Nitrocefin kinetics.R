


library(readr)
library(ggplot2)


HERE <- dirname(rstudioapi::getSourceEditorContext()$path)


Datadf <- data.frame()

Exps <- list.dirs(paste0(HERE,"/Data/Plate_reader_experiments/Enzyme_kinetics/nitrocefinctx/"))

Exps <- c(Exps, list.dirs(paste0(HERE,"/Data/Plate_reader_experiments/Enzyme_kinetics/nitrocefincmy/")))

Exps <- Exps[Exps != paste0(HERE,"/Data/Plate_reader_experiments/Enzyme_kinetics/nitrocefinctx/")]
Exps <- Exps[Exps != paste0(HERE,"/Data/Plate_reader_experiments/Enzyme_kinetics/nitrocefincmy/")]


Fulldata <- data.frame()
for(i in Exps){
  
  if( identical(length(list.files(i,pattern ="^rep1.txt")),as.integer(0)) ){
    next
  }
  
  suppressMessages(
    Datadf <- data.frame( read_delim(paste0(i,"/Rep1.txt"), 
                                     delim = "\t", escape_double = FALSE, col_names = FALSE,
                                     locale = locale(decimal_mark = ",", grouping_mark = "."), 
                                     trim_ws = TRUE)))
  suppressMessages(
    Datadf <- rbind(Datadf, data.frame( read_delim(paste0(i,"/Rep2.txt"), 
                                                   delim = "\t", escape_double = FALSE, col_names = FALSE,
                                                   locale = locale(decimal_mark = ",", grouping_mark = "."), 
                                                   trim_ws = TRUE))))
  suppressMessages(
    Datadf <- rbind(Datadf, data.frame( read_delim(paste0(i,"/Rep3.txt"), 
                                                   delim = "\t", escape_double = FALSE, col_names = FALSE,
                                                   locale = locale(decimal_mark = ",", grouping_mark = "."), 
                                                   trim_ws = TRUE))))
  suppressMessages(
    Datadf <- rbind(Datadf, data.frame( read_delim(paste0(i,"/Rep4.txt"), 
                                                   delim = "\t", escape_double = FALSE, col_names = FALSE,
                                                   locale = locale(decimal_mark = ",", grouping_mark = "."), 
                                                   trim_ws = TRUE))))
  
  
  Datadf <- Datadf[,-c(1,3,4,5,10)]
  
  
  colnames(Datadf) <- c("Well","Wavelength","Read","Abs","Elapsed")
  
  Datadf$Replicate <- 4
  Datadf$Sample <- "UB4"
  
  if(grepl("ctx",i)){
    # next #none redone yet for 100ugml 
    
    Datadf$Enz <- "CTX-M-15"
    
    if(grepl("ph7",i)){
      
      
      
      Datadf$Replicate[Datadf$Well %in% c("A09","A10","B09","B10")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("A11","A12","B11","B12")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("C09","C10","D09","D10")] <- 3
      
      Datadf$Sample[grepl("B09",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("B11",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D09",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D11",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("B10",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("B12",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D10",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D12",Datadf$Well)] <- "NITCTRL"
      
      
      # 
      # Datadf$Replicate[Datadf$Well %in% c("A02","A01","B01","B02")] <- 1
      # 
      # Datadf$Replicate[Datadf$Well %in% c("A04","A03","B03","B04")] <- 2
      # 
      # Datadf$Replicate[Datadf$Well %in% c("A06","A05","B05","B06")] <- 3
      # 
      # Datadf$Sample[grepl("B01",Datadf$Well)] <- "CTXNIT"
      # Datadf$Sample[grepl("B03",Datadf$Well)] <- "CTXNIT"
      # Datadf$Sample[grepl("B05",Datadf$Well)] <- "CTXNIT"
      # Datadf$Sample[grepl("B07",Datadf$Well)] <- "CTXNIT"
      # 
      # Datadf$Sample[grepl("B02",Datadf$Well)] <- "NITCTRL"
      # Datadf$Sample[grepl("B04",Datadf$Well)] <- "NITCTRL"
      # Datadf$Sample[grepl("B06",Datadf$Well)] <- "NITCTRL"
      # Datadf$Sample[grepl("B08",Datadf$Well)] <- "NITCTRL"
      Datadf$ph <- 7
      
      
    }
    if(grepl("ph6",i)){
      # next
      Datadf$Replicate[Datadf$Well %in% c("G01","G02","H01","H02")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("G03","G04","H03","H04")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("G05","G06","H05","H06")] <- 3
      
      Datadf$Sample[grepl("H01",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("H03",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("H05",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("H07",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("H02",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("H04",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("H06",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("H08",Datadf$Well)] <- "NITCTRL"
      
      

      
      
      Datadf$ph <- 6
      
    }
    if(grepl("ph5",i)){
      # next
      
      
      Datadf$Replicate[Datadf$Well %in% c("E01","E02","F01","F02")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("E03","E04","F03","F04")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("E05","E06","F05","F06")] <- 3
      
      Datadf$Sample[grepl("F01",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("F03",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("F05",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("F07",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("F02",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("F04",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("F06",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("F08",Datadf$Well)] <- "NITCTRL"
      # 
      # Datadf$Replicate[Datadf$Well %in% c("D09","D10","E09","E10")] <- 1
      # 
      # Datadf$Replicate[Datadf$Well %in% c("D11","D12","E11","E12")] <- 2
      # 
      # Datadf$Replicate[Datadf$Well %in% c("F09","F10","G09","G10")] <- 3
      # 
      # Datadf$Sample[grepl("E09",Datadf$Well)] <- "CTXTAZ"
      # Datadf$Sample[grepl("E11",Datadf$Well)] <- "CTXTAZ"
      # Datadf$Sample[grepl("G09",Datadf$Well)] <- "CTXTAZ"
      # Datadf$Sample[grepl("G11",Datadf$Well)] <- "CTXTAZ"
      # 
      # Datadf$Sample[grepl("E10",Datadf$Well)] <- "TAZCTRL"
      # Datadf$Sample[grepl("E12",Datadf$Well)] <- "TAZCTRL"
      # Datadf$Sample[grepl("G10",Datadf$Well)] <- "TAZCTRL"
      # Datadf$Sample[grepl("G12",Datadf$Well)] <- "TAZCTRL"
      
      Datadf$ph <- 5
    }
    if(grepl("ph8",i)){
      # next
      
      Datadf$Replicate[Datadf$Well %in% c("A09","A10","B09","B10")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("A11","A12","B11","B12")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("C09","C10","D09","D10")] <- 3
      
      Datadf$Sample[grepl("B09",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("B11",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D09",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D11",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("B10",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("B12",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D10",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D12",Datadf$Well)] <- "NITCTRL"
      
      # Datadf$Replicate[Datadf$Well %in% c("B01","B02","A01","A02")] <- 1
      # 
      # Datadf$Replicate[Datadf$Well %in% c("A03","A04","B03","B04")] <- 2
      # 
      # Datadf$Replicate[Datadf$Well %in% c("A05","A06","B05","B06")] <- 3
      # 
      # Datadf$Sample[grepl("B01",Datadf$Well)] <- "CTXTAZ"
      # Datadf$Sample[grepl("B03",Datadf$Well)] <- "CTXTAZ"
      # Datadf$Sample[grepl("B05",Datadf$Well)] <- "CTXTAZ"
      # Datadf$Sample[grepl("B07",Datadf$Well)] <- "CTXTAZ"
      # 
      # Datadf$Sample[grepl("B02",Datadf$Well)] <- "TAZCTRL"
      # Datadf$Sample[grepl("B04",Datadf$Well)] <- "TAZCTRL"
      # Datadf$Sample[grepl("B06",Datadf$Well)] <- "TAZCTRL"
      # Datadf$Sample[grepl("B08",Datadf$Well)] <- "TAZCTRL"
      
      Datadf$ph <- 8
      
    }
    if(grepl("ph9",i)){
      
      Datadf$Replicate[Datadf$Well %in% c("E09","E10","F09","F10")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("E11","E12","F11","F12")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("G09","G10","H09","H10")] <- 3
      
      Datadf$Sample[grepl("F09",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("F11",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("H09",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("H11",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("F10",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("F12",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("H10",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("H12",Datadf$Well)] <- "NITCTRL"
      # Datadf$Replicate[Datadf$Well %in% c("C01","C02","D01","D02")] <- 1
      # 
      # Datadf$Replicate[Datadf$Well %in% c("C03","C04","D03","D04")] <- 2
      # 
      # Datadf$Replicate[Datadf$Well %in% c("C05","C06","D05","D06")] <- 3
      # 
      # Datadf$Sample[grepl("D01",Datadf$Well)] <- "CTXTAZ"
      # Datadf$Sample[grepl("D03",Datadf$Well)] <- "CTXTAZ"
      # Datadf$Sample[grepl("D05",Datadf$Well)] <- "CTXTAZ"
      # Datadf$Sample[grepl("D07",Datadf$Well)] <- "CTXTAZ"
      # 
      # Datadf$Sample[grepl("D02",Datadf$Well)] <- "TAZCTRL"
      # Datadf$Sample[grepl("D04",Datadf$Well)] <- "TAZCTRL"
      # Datadf$Sample[grepl("D06",Datadf$Well)] <- "TAZCTRL"
      # Datadf$Sample[grepl("D08",Datadf$Well)] <- "TAZCTRL"
      
      Datadf$ph <- 9
      
    }
    
    
    
  } else if(grepl("cmy",i)){
    
    Datadf$Enz <- "CMY-2"
    
    
    if(grepl("ph5",i)){

      Datadf$Replicate[Datadf$Well %in% c("A01","A02","B01","B02")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("A03","A04","B03","B04")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("A05","A06","B05","B06")] <- 3
      
      Datadf$Sample[grepl("B01",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("B03",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("B05",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("B07",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("B02",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("B04",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("B06",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("B08",Datadf$Well)] <- "NITCTRL"
      
      Datadf$ph <- 5
      

    }
    if(grepl("ph6",i)){
      
      Datadf$Replicate[Datadf$Well %in% c("E09","E10","F09","F10")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("E11","E12","F11","F12")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("G09","G10","H09","H10")] <- 3
      
      # Datadf$Replicate[Datadf$Well %in% c("G11","G12","H11","H12")] <- 8
      
      Datadf$Sample[grepl("F09",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("F11",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("H09",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("H11",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("F10",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("F12",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("H10",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("H12",Datadf$Well)] <- "NITCTRL"
      
      Datadf$ph <- 6


      
      
    }
    if(grepl("ph7",i)){
      
      Datadf$Replicate[Datadf$Well %in% c("A01","A02","B01","B02")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("A03","A04","B03","B04")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("A05","A06","B05","B06")] <- 3
      
      Datadf$Sample[grepl("B01",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("B03",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("B05",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("B07",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("B02",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("B04",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("B06",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("B08",Datadf$Well)] <- "NITCTRL"
      
      Datadf$ph <- 7
      
    }
    if(grepl("ph8",i)){

      Datadf$Replicate[Datadf$Well %in% c("C01","C02","D01","D02")] <- 1

      Datadf$Replicate[Datadf$Well %in% c("C03","C04","D03","D04")] <- 2

      Datadf$Replicate[Datadf$Well %in% c("C05","C06","D05","D06")] <- 3

      Datadf$Sample[grepl("D01",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D03",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D05",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D07",Datadf$Well)] <- "ENZ"

      Datadf$Sample[grepl("D02",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D04",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D06",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D08",Datadf$Well)] <- "NITCTRL"
      
      
      Datadf$ph <- 8
      
    }
    if(grepl("ph9",i)){

      
      Datadf$Replicate[Datadf$Well %in% c("E09","E10","F09","F10")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("E11","E12","F11","F12")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("G09","G10","H09","H10")] <- 3
      
      Datadf$Sample[grepl("F09",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("F11",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("H09",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("H11",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("F10",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("F12",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("H10",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("H12",Datadf$Well)] <- "NITCTRL"
      
      Datadf$ph <- 9
      
    }
    
    
    
    
  }
  
  

  
  Fulldata <- rbind(Fulldata, Datadf)
  
  
}
Fulldata$Set <- "100ugml"




Fulltemp <- data.frame()
# Fulldata <- data.frame()
for(i in Exps){
  

  # stop("hey")
  
  
  if(grepl("ctx",i)){
  
    if( identical(length(list.files(i,pattern ="nit6rep")),as.integer(0)) ){
      next
    }
    
  suppressMessages(
    Datadf <- data.frame( read_delim(paste0(i,"/nit6rep1.txt"), 
                                     delim = "\t", escape_double = FALSE, col_names = FALSE,
                                     locale = locale(decimal_mark = ",", grouping_mark = "."), 
                                     trim_ws = TRUE)))
  suppressMessages(
    Datadf <- rbind(Datadf, data.frame( read_delim(paste0(i,"/nit6rep2.txt"), 
                                                   delim = "\t", escape_double = FALSE, col_names = FALSE,
                                                   locale = locale(decimal_mark = ",", grouping_mark = "."), 
                                                   trim_ws = TRUE))))
  suppressMessages(
    Datadf <- rbind(Datadf, data.frame( read_delim(paste0(i,"/nit6rep3.txt"), 
                                                   delim = "\t", escape_double = FALSE, col_names = FALSE,
                                                   locale = locale(decimal_mark = ",", grouping_mark = "."), 
                                                   trim_ws = TRUE))))
  suppressMessages(
    Datadf <- rbind(Datadf, data.frame( read_delim(paste0(i,"/nit6rep4.txt"), 
                                                   delim = "\t", escape_double = FALSE, col_names = FALSE,
                                                   locale = locale(decimal_mark = ",", grouping_mark = "."), 
                                                   trim_ws = TRUE))))
  
  } else if(grepl("cmy",i)){
    
    if( identical(length(list.files(i,pattern ="nit10rep")),as.integer(0)) ){
      next
    }
    
    suppressMessages(
      Datadf <- data.frame( read_delim(paste0(i,"/nit10rep1.txt"), 
                                       delim = "\t", escape_double = FALSE, col_names = FALSE,
                                       locale = locale(decimal_mark = ",", grouping_mark = "."), 
                                       trim_ws = TRUE)))
    suppressMessages(
      Datadf <- rbind(Datadf, data.frame( read_delim(paste0(i,"/nit10rep2.txt"), 
                                                     delim = "\t", escape_double = FALSE, col_names = FALSE,
                                                     locale = locale(decimal_mark = ",", grouping_mark = "."), 
                                                     trim_ws = TRUE))))
    suppressMessages(
      Datadf <- rbind(Datadf, data.frame( read_delim(paste0(i,"/nit10rep3.txt"), 
                                                     delim = "\t", escape_double = FALSE, col_names = FALSE,
                                                     locale = locale(decimal_mark = ",", grouping_mark = "."), 
                                                     trim_ws = TRUE))))
    suppressMessages(
      Datadf <- rbind(Datadf, data.frame( read_delim(paste0(i,"/nit10rep4.txt"), 
                                                     delim = "\t", escape_double = FALSE, col_names = FALSE,
                                                     locale = locale(decimal_mark = ",", grouping_mark = "."), 
                                                     trim_ws = TRUE))))
    
    
    
    
  }
  
  Datadf <- Datadf[,-c(1,3,4,5,10)]
  
  
  colnames(Datadf) <- c("Well","Wavelength","Read","Abs","Elapsed")
  
  Datadf$Replicate <- 4
  Datadf$Sample <- "UB4"
  
  if(grepl("ctx",i)){
    Datadf$Enz <- "CTX-M-15"
    
    if(grepl("ph7",i)){
      
      
      Datadf$Replicate[Datadf$Well %in% c("A09","A10","B09","B10")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("A11","A12","B11","B12")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("C09","C10","D09","D10")] <- 3
      
      Datadf$Sample[grepl("B09",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("B11",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D09",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D11",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("B10",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("B12",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D10",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D12",Datadf$Well)] <- "NITCTRL"
      Datadf$ph <- 7
      
      
    }
    if(grepl("ph6",i)){
      
      Datadf$Replicate[Datadf$Well %in% c("C01","C02","D01","D02")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("C03","C04","D03","D04")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("C05","C06","D05","D06")] <- 3
      
      Datadf$Sample[grepl("D01",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D03",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D05",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D07",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("D02",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D04",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D06",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D08",Datadf$Well)] <- "NITCTRL"
      
      
      
      
      Datadf$ph <- 6
      
    }
    if(grepl("ph5",i)){
      
      
      Datadf$Replicate[Datadf$Well %in% c("E01","E02","F01","F02")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("E03","E04","F03","F04")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("E05","E06","F05","F06")] <- 3
      
      Datadf$Sample[grepl("F01",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("F03",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("F05",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("F07",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("F02",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("F04",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("F06",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("F08",Datadf$Well)] <- "NITCTRL"
      
      
      
      
      Datadf$ph <- 5
      
    }
    if(grepl("ph8",i)){
      
      Datadf$Replicate[Datadf$Well %in% c("G01","G02","H01","H02")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("G03","G04","H03","H04")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("G05","G06","H05","H06")] <- 3
      
      Datadf$Sample[grepl("H01",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("H03",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("H05",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("H07",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("H02",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("H04",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("H06",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("H08",Datadf$Well)] <- "NITCTRL"
      
      
      
      
      Datadf$ph <- 8
      
    }
    if(grepl("ph9",i)){
      # stop("no entry")
      
      
      Datadf$Replicate[Datadf$Well %in% c("A01","A02","B01","B02")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("A03","A04","B03","B04")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("A05","A06","B05","B06")] <- 3
      
      Datadf$Sample[grepl("B01",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("B03",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("B05",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("B07",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("B02",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("B04",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("B06",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("B08",Datadf$Well)] <- "NITCTRL"
      
      
      
      
      Datadf$ph <- 9
      
    }
  }
  if(grepl("cmy",i)){
    Datadf$Enz <- "CMY-2"
    if(grepl("ph7",i)){
      
      Datadf$Replicate[Datadf$Well %in% c("C01","C02","D01","D02")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("C03","C04","D03","D04")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("C05","C06","D05","D06")] <- 3
      
      Datadf$Sample[grepl("D01",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D03",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D05",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D07",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("D02",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D04",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D06",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D08",Datadf$Well)] <- "NITCTRL"
      
      Datadf$ph <- 7
      
    }
    if(grepl("ph6",i)){
      
      Datadf$Replicate[Datadf$Well %in% c("C01","C02","D01","D02")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("C03","C04","D03","D04")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("C05","C06","D05","D06")] <- 3
      
      Datadf$Sample[grepl("D01",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D03",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D05",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D07",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("D02",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D04",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D06",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D08",Datadf$Well)] <- "NITCTRL"
      
      Datadf$ph <- 6
      
    }
    if(grepl("ph5",i)){
      
      Datadf$Replicate[Datadf$Well %in% c("G01","G02","H01","H02")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("G03","G04","H03","H04")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("G05","G06","H05","H06")] <- 3
      
      Datadf$Sample[grepl("H01",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("H03",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("H05",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("H07",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("H02",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("H04",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("H06",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("H08",Datadf$Well)] <- "NITCTRL"
      
      Datadf$ph <- 5
      
    }
    if(grepl("ph8",i)){
      
      Datadf$Replicate[Datadf$Well %in% c("A09","A10","B09","B10")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("A11","A12","B11","B12")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("C09","C10","D09","D10")] <- 3
      
      Datadf$Sample[grepl("B09",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("B11",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D09",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("D11",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("B10",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("B12",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D10",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("D12",Datadf$Well)] <- "NITCTRL"
      
      Datadf$ph <- 8
      
    }
    if(grepl("ph9",i)){
      
      Datadf$Replicate[Datadf$Well %in% c("E09","E10","F09","F10")] <- 1
      
      Datadf$Replicate[Datadf$Well %in% c("E11","E12","F11","F12")] <- 2
      
      Datadf$Replicate[Datadf$Well %in% c("G09","G10","H09","H10")] <- 3
      
      Datadf$Sample[grepl("F09",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("F11",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("H09",Datadf$Well)] <- "ENZ"
      Datadf$Sample[grepl("H11",Datadf$Well)] <- "ENZ"
      
      Datadf$Sample[grepl("F10",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("F12",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("H10",Datadf$Well)] <- "NITCTRL"
      Datadf$Sample[grepl("H12",Datadf$Well)] <- "NITCTRL"
      
      Datadf$ph <- 9
      
    }
    
    
  }
  

  
  Datadf$Set <- "10ugml"
  
  Fulltemp <- rbind(Fulltemp, (Datadf))
  
  
}


Fulldata <- rbind(Fulldata, Fulltemp)



Intercepts <- function(x){
  
  what <- c()
  for( i in x){
    
    what <- c(what, i$coefficients[1])
  }
  
  as.numeric(what)
}




Slopes <- function(x){
  
  what <- c()
  for( i in x){
    
    what <- c(what, i$coefficients[2])
  }
  
  as.numeric(what)
  
}

Nitconc2 <- function(Abs){
  
  Nitfit2$coefficients[1]+Nitfit2$coefficients[2]*Abs
}

Nitconc <- function(Abs){
  
  Nitfit$coefficients[1]+Nitfit$coefficients[2]*Abs
}


# 
Fulldata$conc <- 0


Kineticsdat <- data.frame()
for(x in unique(Fulldata$Enz)){
  for(i in 1:length(unique(Fulldata$Set))){
    
    TEMPDF <- subset(Fulldata,
                     Fulldata$Set == unique(Fulldata$Set)[i] &
                       Fulldata$Enz == x)
    
    
    for(j in unique(TEMPDF$ph)){
      
      test1 <- rbind( 
        subset(TEMPDF, TEMPDF$Sample == "NITCTRL" & TEMPDF$Wavelength == 390 & TEMPDF$Read == 1 & TEMPDF$ph == j),
        
        subset(TEMPDF, TEMPDF$Sample == "NITCTRL" & TEMPDF$Wavelength == 490 & TEMPDF$Read == 1 & TEMPDF$ph == j) 
      )
      
      
      test1$Conc <- 0
      
      
      test1$Conc[test1$Wavelength == 390 & test1$Set == "100ugml"] <- (40*500/200)*0.95 # 95% purity of 100 ug/ml 
      if(x == "CTX-M-15"){
        test1$Conc[test1$Wavelength == 390 & test1$Set == "10ugml"] <- (6.5*500/200)*0.95
        # test1$Abs[test1$Wavelength == 390] 
        
        #ph5 correction /mean(c(.4264,.4049))/mean(c(.3833,.4032)) from spectrum hydrolysis script
        #ph9 correction /0.9855274
        
      } else {
        test1$Conc[test1$Wavelength == 390 & test1$Set == "10ugml"] <- (10*500/200)*0.95
        
        
      }
      
      if( j == 5){
        test1$Abs[test1$Wavelength == 390] <- test1$Abs[test1$Wavelength == 390]/1.056961
      } else if( j == 9 ){
        test1$Abs[test1$Wavelength == 390] <- test1$Abs[test1$Wavelength == 390]/0.9855274
      }
      
      
      test1$molc <- test1$Conc/516.5*1000
      
      Nitfit2 <- summary(lm(molc~Abs, test1))
      # test1$Conc2 <- Nitconc2(test1$Abs)

      
      TEMPDF$conc[TEMPDF$Sample != "UB4" & TEMPDF$Wavelength == 490 & TEMPDF$ph == j] <- Nitconc2(TEMPDF$Abs[TEMPDF$Sample != "UB4" & TEMPDF$Wavelength == 490 & TEMPDF$ph == j] )
      
      Fulldata$conc[Fulldata$Sample !="UB4" & Fulldata$Wavelength == 490 & Fulldata$Set == unique(Fulldata$Set)[i] & Fulldata$ph == j & Fulldata$Enz == x] <- Nitconc2(Fulldata$Abs[Fulldata$Sample !="UB4" & Fulldata$Wavelength == 490 & Fulldata$Set == unique(Fulldata$Set)[i] & Fulldata$ph == j & Fulldata$Enz == x])
      
      
      test2 <- rbind( 
        subset(TEMPDF, TEMPDF$Sample == "NITCTRL" & TEMPDF$Wavelength == 390 & TEMPDF$Read == 1 & TEMPDF$ph == j),
        
        subset(TEMPDF, TEMPDF$Sample == "UB4" & TEMPDF$Wavelength == 390 & TEMPDF$Read == 1 & TEMPDF$ph == j) 
      )
      
      
      test2$Conc <- 0
      
      
      test2$Conc[test2$Wavelength == 390 & test2$Set == "100ugml" & test2$Sample == "NITCTRL"] <- (40*500/200)*0.95 # 95% purity of 100 ug/ml 
      
      if(x == "CTX-M-15"){
        test2$Conc[test2$Wavelength == 390 & test2$Set == "10ugml" & test2$Sample == "NITCTRL"] <- (6.5*500/200)*0.95
        
      } else {
        test2$Conc[test2$Wavelength == 390 & test2$Set == "10ugml" & test2$Sample == "NITCTRL"] <- (10*500/200)*0.95
        
        
      }
      
      test2$molc <- test2$Conc/516.5*1000
      
      Nitfit <- summary(lm(molc~Abs, test2))
      
      TEMPDF$conc[TEMPDF$Sample != "UB4" & TEMPDF$Wavelength == 390 & TEMPDF$ph == j] <- Nitconc(TEMPDF$Abs[TEMPDF$Sample != "UB4" & TEMPDF$Wavelength == 390 & TEMPDF$ph == j] )
      
      Fulldata$conc[Fulldata$Sample !="UB4" & Fulldata$Wavelength == 390 & Fulldata$Set == unique(Fulldata$Set)[i] & Fulldata$ph == j & Fulldata$Enz == x] <- Nitconc(Fulldata$Abs[Fulldata$Sample !="UB4" & Fulldata$Wavelength == 390 & Fulldata$Set == unique(Fulldata$Set)[i] & Fulldata$ph == j & Fulldata$Enz == x])
      
      
      stop1 <- 4
      if( j == 9 & x == "CTX-M-15"& test1$Set[1] == "100ugml"){
        stop1 <- 20
        #reaction speeds up midway - include more datapoints
      }
      if( j == 7 & x == "CTX-M-15"& test1$Set[1] == "100ugml"){
        stop1 <- 10
        #reaction speeds up midway - include more datapoints
      }
      
      
      
      Fitctx <- list()
      Fitctrl <- list()
      Initconcctx <- list()
      Initconcctrl <- list()
      for(z in 1:length(unique(TEMPDF$Replicate))){
        
        if( !identical(dim(subset(TEMPDF,TEMPDF$Read <= stop1 & TEMPDF$Replicate == z & TEMPDF$Sample == "ENZ" & TEMPDF$ph == j))[1],as.integer(0)) ){
      
          Fitctx[[z]] <- lm(conc~Elapsed,subset(TEMPDF,TEMPDF$Read <= stop1 & TEMPDF$Wavelength == 490 & TEMPDF$Replicate == z & TEMPDF$ph == j & TEMPDF$Sample == "ENZ"))
          

          Initconcctx[[z]] <- subset(TEMPDF,TEMPDF$Read <= stop1 & TEMPDF$Sample == "ENZ" & TEMPDF$Replicate == z & TEMPDF$Wavelength == 390 & TEMPDF$ph == j)$conc[1]
        }
        
        

      }
      

      
      num <- length(unique(subset(TEMPDF,TEMPDF$Read <= stop1 & TEMPDF$Sample == "ENZ" & TEMPDF$ph == j)$Replicate))

      
      dattemp <- data.frame( Replicate = c(unique(subset(TEMPDF,TEMPDF$Read <= stop1 & TEMPDF$Sample == "ENZ" & TEMPDF$ph == j)$Replicate)),
                             Sample = c(rep("ENZ",num)),
                             SLOP = c(Slopes(Fitctx) ),
                             INT = c(Intercepts(Fitctx)),
                             Vcorr = (c(Slopes(Fitctx))),
                             ph = rep(j, num),
                             Set = rep(unique(Fulldata$Set)[i],num),
                             Initconc = c(unlist(Initconcctx)) ,
                             Enzyme = x

      )
      

      
      
      
      
      Kineticsdat <- rbind(Kineticsdat, dattemp)
    }
  }
}
# }
colnames(Kineticsdat) <- c("Replicate","Sample","SLOP","INT","Vcorr","ph","Set","initconc","Enzyme") #,"Wavelength")


#QC of linear regressions
ENZY <- "CMY-2" #enzyme : CTX-M-15 or CMY-2
x1 <- 7 #pH 



# 
ggplot(subset(Fulldata, Fulldata$Sample != "UB4" & Enz == ENZY  &Wavelength == 490  & ph == x1 ), aes(x = Elapsed, y = conc, color = as.factor(Replicate))) +
  # geom_line(alpha = 0.5, linewidth = 1.5) +
  geom_point(alpha = 0.5) +
  geom_abline(data = subset(Kineticsdat,  Enzyme ==ENZY & ph ==x1 ), aes(slope = SLOP, intercept = INT, linetype = as.factor(Set), group = interaction(Sample, Replicate,Enzyme)), color = "black", linetype = "solid")+
  # geom_text(x = 0, y = 350, label = paste0("Rep = ",reppp)) +
  facet_wrap(~ph*Set*Sample) 

#
Kineticsdat$ph2 <- paste0(Kineticsdat$ph)


ggplot(subset(Kineticsdat[-c(13,42,58,61,68),]), aes( x = ph2, y = SLOP, fill = as.factor(Enzyme))) +
  # geom_violin() +
  geom_boxplot() +
  # geom_jitter(aes(color = Enzyme)) +
  # geom_jitter(color = "red")+ 
  # stat_compare_means(method = "t.test" , comparisons = Compare, aes(label = p.signif), p.adjust.methods = "fdr") +
  # xlab("pH") +
  facet_wrap(~Set) +
  # coord_cartesian(ylim = c(0,0.4)) +
  # stat_pvalue_manual()
  ylab( "Rate [µM/s]") + #expression(paste("Rate [µM/s", s^-1  ,"]")))+
  # ylab((expression( paste("Estimated Kcat [", s^-1 ,"]")))) +
  ggtitle("Hydrolysis of nitrocefin, n = 4, [E] = 1 nM, [S] = 190 µM") +
  theme_bw()  +
  scale_fill_discrete(name = "Protein")
# facet_wrap(~Enzyme)
# scale_y_continuous(breaks = seq(0,10,1))

#all outliers removed as determined by boxplot method

ggplot((Kineticsdat), aes( x = ph2, y = SLOP, fill = as.factor(Enzyme))) +
  # geom_violin() +
  geom_boxplot() +
  geom_point(data = Kineticsdat[c(13,42,58,61,68),], size = 2,color = "red")+
  facet_wrap(~Set) 
#-c(13,42,58,61,68)


Kineticsdatsafe <- Kineticsdat 

Kineticsdat <- Kineticsdat[-c(13,42,58,61,68),]


# install.packages("renz")

library(renz)
#use library(renz) and dir.MM() to estimate Km and Vmax  and weighted linear regression lineweaver-burk (compare both methods)

# For ctx-m-15: 
Ec1 <- ( (17.5*(114.55/10000))/200 )

Ec2 <- ( (50*(86.23/10000))/200 )



Finaldata <- data.frame()
for(j in 1:length(unique(Kineticsdat$Enzyme))){
  for(i in 1:length(unique(Kineticsdat$ph))){
    
    # if( unique(Kineticsdat$ph)[i] == 9 ){
    #   next
    # }
    
    
    # hey <- sample(1:6,1)
    testset <- subset(Kineticsdat, Kineticsdat$ph == unique(Kineticsdat$ph)[i] & Kineticsdat$Sample == "ENZ" & Kineticsdat$Enzyme == unique(Kineticsdat$Enzyme)[j] )
    # testset %>% group_by(Set) %>% summarize( SLOP, initconc)l
    # hey <- sample(1:8,1)
    # #exceptions, removal of outliers etc:
    # if( testset$Enzyme[1] == "CTX-M-15" & testset$ph[1] == 8){
    #   
    #   testset <- testset[-c(1),]
    # }
    # if( testset$Enzyme[1] == "CMY-2" & testset$ph[1] == 5){
    #   
    #   testset <- testset[-c(2,5),]
    # }
    # if( testset$Enzyme[1] == "CMY-2" & testset$ph[1] == 6){
    #   
    #   testset <- testset[-c(8),]
    # }
    # if( testset$Enzyme[1] == "CMY-2" & testset$ph[1] == 9){
    #   
    #   testset <- testset[-c(2),]
    # }
    
    test1 <- dir.MM(data.frame( V1 = testset$initconc, V2 = testset$Vcorr ), unit_S = paste0(testset$Enzyme[1],"ph",testset$ph2[1]) )
    # test1 <- lb(data.frame( V1 = testset$initconc, V2 = testset$Vcorr ),weighting = TRUE)
    
    # if( unique(Kineticsdat$ph)[i] == 9 ){
    #   test1 <- hw(data.frame( V1 = subset(Kineticsdat, Kineticsdat$Sample == "CTX" & Kineticsdat$ph == unique(Kineticsdat$ph)[i])$initconc, V2 = subset(Kineticsdat, Kineticsdat$Sample == "CTX" & Kineticsdat$ph == unique(Kineticsdat$ph)[i])$Vcorr ))
    # #   Finaldata <- rbind(Finaldata, cbind(test1$fitted_parameters[1][[1]], test1$fitted_parameters[2][[1]],(test1$fitted_parameters[2][[1]]/ Ec),  (test1$fitted_parameters[2][[1]]/ Ec) / test1$fitted_parameters[1][[1]] * 1000,  unique(Kineticsdat$ph)[i]  ))
    # #   
    # # } else {
    # test1 <- dir.MM(data.frame( V1 = subset(Kineticsdat, Kineticsdat$Sample == "CTX" & Kineticsdat$ph == unique(Kineticsdat$ph)[i])$initconc, V2 = subset(Kineticsdat, Kineticsdat$Sample == "CTX" & Kineticsdat$ph == unique(Kineticsdat$ph)[i])$Vcorr ))
    if( testset$Enzyme[1] == "CTX-M-15"){
      
      Ec <- Ec1 
    } else { Ec <- Ec2}    
    
    Finaldata <- rbind(Finaldata, cbind(test1$parameters[1][[1]],(test1$parameters[2][[1]]/ Ec),  (test1$parameters[2][[1]]/ Ec) / test1$parameters[1][[1]],  unique(Kineticsdat$ph)[i], unique(Kineticsdat$Enzyme)[j]  ))
    # Finaldata <- rbind(Finaldata,  cbind(test1$fitted_parameters[1], test1$fitted_parameters[2],(test1$fitted_parameters[2]/ Ec),  ((test1$fitted_parameters[2]/ Ec) / test1$fitted_parameters[1] ),  unique(Kineticsdat$ph)[i]  ))
    
    # }
    
    
    
    
    
  }
}
colnames(Finaldata) <- c("Km","Kcat","Kcat/Km","pH","Enzyme")



Finaldata$Km <- round(as.numeric(Finaldata$Km), 2)

Finaldata$Kcat <- round(as.numeric(Finaldata$Kcat), 2)

Finaldata$`Kcat/Km` <- round(as.numeric(Finaldata$`Kcat/Km`), 2)

Finaldata


ggplot(Finaldata, aes(x = pH, y = (Kcat), color = Enzyme, group = Enzyme )) +
  geom_point() +
  geom_smooth()


