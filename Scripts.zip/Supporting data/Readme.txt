This directory contains scripts used to analyze and plot from the raw data 

EUVsec2 panel mic.R - Contains raw data from MIC experiments done at different pH's and temp. using EUVSEC2 panels

Growthratedata.R - Load raw growth data and growth rates to ensure proper estimate of growth rates (for QC purposes). Generates Finaldata.txt for fitness landscape calculations

Nitrocefin kinetics.R - Load enzyme kinetics data and compute enzymatic parameters Km and Kcat using NLS

Spectrumhydrolysis.R - Load spectrums of hydrolysed and unhydrolysed nitrocefin

Clinical isolates.R - Constains raw data from MIC experiment done on clinical isolates and plot

Changingconditionsplot.R - Contains scripts to generate fitness landscape plots from growth rate data.

Co-culture1plot.R - Contains scripts to analyze KMA output from "Co-culture1" and plot figure 4

Co-culture2plot.R - Contains scripts to analyze KMA output from "Co-culture2" and plot figure 5

Co-culture3plot.R - Contains scripts to analyze KMA output from "Co-culture3" and plot figure 6