

library(readr)
library(ggplot2)



HERE <- dirname(rstudioapi::getSourceEditorContext()$path)


UVset <- data.frame(read_delim(paste0(dirname(HERE),"/Data/Nitrocefin/calibration spectrum2.txt"), 
           delim = "\t", escape_double = FALSE, 
           locale = locale(decimal_mark = ",", grouping_mark = "."), 
           trim_ws = TRUE))

HYDROset <- data.frame(read_delim("~/Scripts/Enzymekinetics/Data/Nitrocefin/hydrolysis test.txt", 
                       delim = "\t", escape_double = FALSE, 
                       locale = locale(decimal_mark = ",", grouping_mark = "."), 
                       trim_ws = TRUE, skip = 1))

which(is.na(HYDROset[1,]))

Hydro1 <- HYDROset[,1:25]
Hydro2 <- HYDROset[,27:51]
Hydro3 <- HYDROset[,53:77]
Hydro4 <- HYDROset[,79:103]
Hydro5 <- HYDROset[,105:129]
Hydro6 <- HYDROset[,131:155]

colnames(Hydro1) <- colnames(UVset)
colnames(Hydro2) <- colnames(UVset)
colnames(Hydro3) <- colnames(UVset)
colnames(Hydro4) <- colnames(UVset)
colnames(Hydro5) <- colnames(UVset)
colnames(Hydro6) <- colnames(UVset)

Hydro1$elaps <- 0
Hydro2$elaps <- 240
Hydro3$elaps <- 480
Hydro4$elaps <- 720
Hydro5$elaps <- 960
Hydro6$elaps <- 1200



Hydro <- rbind(Hydro1, Hydro2, Hydro3, Hydro4, Hydro5, Hydro6)


Fulldata <- data.frame()



for(i in 2:dim(UVset)[2]){

  Fulldata <- rbind(Fulldata, cbind(UVset[,1], UVset[,i],UVset[,i]-UVset[,19+((i-2)%%6)], colnames(UVset)[i]))
  # Fulldata <- rbind(Fulldata, cbind(UVset[,1],UVset[,i],UVset[,i]-rowMeans(UVset[,grepl("10",colnames(UVset),fixed=TRUE)]), UVset[,i]-rowMeans(UVset[,grepl("11",colnames(UVset),fixed=TRUE)]), 
  #                                   colnames(UVset)[i],c(500*2^-seq(0,8,1),0,0,0)[c(((i-2)%%12)+1)], "UV" ))
  # 
  # Fulldata <- rbind(Fulldata, cbind(VISset[,1],VISset[,i],VISset[,i]-rowMeans(VISset[,grepl("10",colnames(VISset),fixed=TRUE)]), VISset[,i]-rowMeans(VISset[,grepl("11",colnames(VISset),fixed=TRUE)]), 
  #                                   colnames(UVset)[i],c(500*2^-seq(0,8,1),0,0,0)[c(((i-2)%%12)+1)], "VIS" ))
  
}


colnames(Fulldata) <- c("Wavelength","Abs","Absn","Well")

Fulldata$Elaps <- 0
Fulldata$Sample <- "Blank"

Fulldata2 <- data.frame()
for(i in 2:25){
  
  Fulldata2 <- rbind(Fulldata2, cbind(Hydro[,1], Hydro[,i], Hydro[,i]-Hydro[,19+((i-2)%%6)], colnames(Hydro)[i], Hydro[26]))

}
colnames(Fulldata2) <- c("Wavelength","Abs","Absn","Well","Elaps")
Fulldata2$Sample <- "ENZ"

FULLERdata <- rbind(Fulldata, Fulldata2)

FULLERdata$Initconc <- 0
FULLERdata$Initconc[grepl("E",FULLERdata$Well)] <- 100
FULLERdata$Initconc[grepl("F",FULLERdata$Well)] <- 50
FULLERdata$Initconc[grepl("G",FULLERdata$Well)] <- 10
FULLERdata$Initconc[grepl("H",FULLERdata$Well)] <- 0

FULLERdata$Rep <- 1
FULLERdata$Rep[grepl(10, FULLERdata$Well)] <- 2
FULLERdata$Rep[grepl(11, FULLERdata$Well)] <- 2
FULLERdata$Rep[grepl(12, FULLERdata$Well)] <- 2

FULLERdata$ph <- 5
FULLERdata$ph[grepl(08, FULLERdata$Well)] <- 7
FULLERdata$ph[grepl(11, FULLERdata$Well)] <- 7

FULLERdata$ph[grepl(09, FULLERdata$Well)] <- 9
FULLERdata$ph[grepl(12, FULLERdata$Well)] <- 9

FULLERdata$Wavelength <- as.numeric(FULLERdata$Wavelength)
FULLERdata$Abs <- as.numeric(FULLERdata$Abs)
FULLERdata$Absn <- as.numeric(FULLERdata$Absn)

FULLERdata$ph <- as.factor(FULLERdata$ph)


rm(Hydro);rm(Hydro1);rm(Hydro2);rm(Hydro3);rm(Hydro4);rm(Hydro5);rm(Hydro6);rm(Fulldata2);rm(i);rm(HYDROset);rm(UVset)
Fulldata <- FULLERdata


rm(FULLERdata)# ggplot(subset(Fulldata, Fulldata$Rep == 1), aes(x = Wavelength, y = Abs, colour = ph, group = interaction(Initconc,ph))) +
#   geom_line() +
#   scale_x_continuous(breaks = c(seq(250,800,50)))
#   # geom_point()
# 
# Fulldata$weird <- Fulldata$Abs - Fulldata$Abs[Fulldata$Sample == "Blank"]



tempdf <- subset(Fulldata, Fulldata$Rep == 1 & Fulldata$Elaps == 0)

# 
tempdf[tempdf$Wavelength %in% c(390) & tempdf$Sample == "Blank" & tempdf$Initconc == 100,]
tempdf[tempdf$Wavelength %in% c(490) & tempdf$Sample == "Blank" & tempdf$Initconc == 100,]
# 
# 
# # ph 5 correcting rep1 .4264/.4032, rep2 .4049/.3833 
# 
tempdf$Abs[tempdf$Wavelength %in% c(390,490) & tempdf$Sample == "Blank" & tempdf$Initconc == 100 ]
tempdf$Abs[tempdf$Wavelength %in% c(390,490) & tempdf$Sample == "ENZ" & tempdf$Initconc == 100 ]



ggplot(tempdf[tempdf$Initconc == 100 & tempdf$ph == 7,], aes(x = Wavelength, y = Abs, linetype = factor(Sample,labels = c("None","Enzyme")) )) +
  geom_line() +
  # geom_hline(yintercept = tempdf$Abs[tempdf$Wavelength %in% c(390,490) & tempdf$Sample == "Blank" & tempdf$Initconc == 100 ]) +
  # facet_wrap(~ph) +
  theme_bw() +
  scale_linetype_discrete(name = "Treatment") +
  ylab("Absorbance")+
  xlab("Wavelength [nm]") +
  # scale_color_discrete(name = "Treatment") +
  annotate("segment", x = 340, xend = 640, y = 0.4235  , yend = 0.4235, linetype = "dashed"   ) +
  annotate("segment", x = 490, xend = 490, y = 0.1033  , yend = 0.4235 , linetype = "dashed"   ) +
  annotate("segment", x = 340, xend = 640, y = 0.1033, yend = 0.1033, linetype = "dashed") +
  annotate("text",x = 490, y = 0.07, label = "490nm") +
  annotate("text",x = 390, y = 0.46, label = "390nm") +
  annotate("text",x = 680, y = 0.4235, label = "100% ") +
  annotate("text",x = 680, y = 0.1033, label = "0%") +
  ggtitle("Nitrocefin hydrolysis quantification")


ggsave("Nitrocefinprodcalib.svg",device="svg")



tempdf <- subset(Fulldata, Fulldata$Rep == 1 & Fulldata$Elaps == 0 & Fulldata$Sample == "Blank")

ggplot(tempdf[tempdf$Initconc %in% c(0,100) & tempdf$ph == 7,], aes(x = Wavelength, y = Abs, linetype = factor(Initconc,levels = c(100,0), labels = c("Nitrocefin","Solvent control")) )) +
  geom_line() +
  # geom_hline(yintercept = tempdf$Abs[tempdf$Wavelength %in% c(390,490) & tempdf$Sample == "Blank" & tempdf$Initconc == 100 ]) +
  # facet_wrap(~ph) +
  theme_bw() +
  scale_linetype_discrete(name = "Sample") +
  ylab("Absorbance")+
  xlab("Wavelength [nm]") +
  # scale_color_discrete(name = "Treatment") +
  annotate("segment", x = 340, xend = 440, y = 0.4235  , yend = 0.4235, linetype = "dashed"   ) +
  annotate("segment", x = 390, xend = 390, y = 0.0257  , yend = 0.4235 , linetype = "dashed"   ) +
  annotate("segment", x = 390, xend = 390, y = 0.0257 , yend = 0.0257, linetype = "dashed") +
  # annotate("text",x = 490, y = 0.07, label = "490nm") +
  annotate("text",x = 390, y = 0.45, label = "390nm") +
  annotate("text",x = 540, y = 0.4235, label = "100µg/ml") +
  annotate("text",x = 500, y = 0.05, label = "0µg/ml") +
  ggtitle("Nitrocefin substrate quantification")

ggsave("Nitrocefinsubstcalib.svg",device="svg")


