
library(ggplot2)
library(readr)
library(dplyr)
library(RColorBrewer)
library(prodlim)
#Fitness phase diagram:


HERE <- dirname(rstudioapi::getSourceEditorContext()$path)

Finaldata <- read_tsv(paste0(HERE,"/Data/Fitnesslandscape/Finaldata.txt"))

#Changing conditions

# function with inputs: ph1, ph2, finaldata, intervaldur, intervals

#generate a phasedf-like dataframe 


#implement variable for p2dfgen to output growth curves (ie. input: n, where n is how often to make a data point in minutes)
P2dfgen <- function(ph1, ph2, df, Idur, In, Z, skew=NULL){
  
  Phasedf <- data.frame()
  
  nstart <- 250000 #0.5 mcfarland / 600
  # i <- 1
  
  for(i in 1:length(unique(df$Conc))){
    df1 <- subset(df, df$pH == ph1 & df$Conc == unique(df$Conc)[order(unique(df$Conc))][i] )
    df2 <- subset(df, df$pH == ph2 & df$Conc == unique(df$Conc)[order(unique(df$Conc))][i] )
    
    #Source of growthrates    
    a1 <- df1 %>% select( sEXP2, Slo, gentime, Strain3) %>% group_by(Strain3) %>% summarise( Mslo = mean(Slo), Msx = mean(sEXP2)*Z, Mgen = mean(gentime) )
    b1 <- df2 %>% select( sEXP2, Slo, gentime, Strain3) %>% group_by(Strain3) %>% summarise( Mslo = mean(Slo), Msx = mean(sEXP2)*Z, Mgen = mean(gentime) )
    
    
    
    #if no data exists, e.g. unique(a1$Strain3,b1$Strain3) is empty, we go next
    if( identical(length(unique(c(a1$Strain3,b1$Strain3))),as.integer(0)) ){
      # print(paste0("conc ",unique(df$Conc)[order(unique(df$Conc))][i]," skipped"))
      next
    }
    
    c1 <- data.frame(Strain = unique(c(a1$Strain3,b1$Strain3)), cells = nstart )
    
    if(!is.null(skew)){
      
      if(skew > 1 | skew < 0 | !(skew > 0) | !(skew < 1)){
        stop("Skew must be between 1 and 0, not including")
      }
      
      
      
      
      c1$cells[c1$Strain == "CMYCTX"] <- c1$cells[c1$Strain == "CMYCTX"]*skew
      
      
      c1$cells[!c1$Strain == "CMYCTX"] <- c1$cells[!c1$Strain == "CMYCTX"]*(1-skew)
      
      
    }
    c1$nstart <- c1$cells
    
    # print(c1)
    for(j in 1:In){
      #Dilute cells at the start of each new interval after j=1?
      if(j != 1){
        c1$cells <- c1$cells / 20
      }
      if( identical(j %% 2,0)){
        #if even we use ph2
        
        c1 <- Growexp(c1, b1, Idur)
        
      } else {
        #if odd, we use ph1
        
        c1 <- Growexp(c1, a1, Idur)
        
      }
      
    }  
    #Which strain has the most cells?
    c2 <- c1$Strain[c1$cells == max(c1$cells)]
    
    #Compute relative fitness for c2: which is the log2 fold change between number of cells and starting cells
    
    RFc2 <- log2(c1$cells[c1$cells == max(c1$cells)]/c1$nstart[c1$cells == max(c1$cells)])
    
    RFc3 <- log2(c1$cells[c1$cells == max(c1$cells)])
    
    if( length(c2) > 1){
      #If its a tie
      c2 <- "Blank"
      # c2 <- interaction(c1$Strain) 
      # c2 <- combn(as.list(c1$Strain),2,interaction)
    }
    
    
    Phasedf <- rbind(Phasedf, cbind( as.character(interaction(ph1,ph2)), unique(df$Conc)[order(unique(df$Conc))][i],c2, RFc2, RFc3    ))
    
    
  }
  
  # print(c1)
  colnames(Phasedf) <- c("pHs","Conc","Strain", "RF","log2cells")
  
  Phasedf
}



Growexp <- function(c1, ab, Idur ){
  
  
  for(i in 1:length(c1$Strain)){
    #Ensure we use the correct growth rate for each strain
    
    
    SLO <- ab$Mslo[ab$Strain3== c1$Strain[i]]
    # print(paste0("Strain: ",c1$Strain[i], " has slope ", SLO))
    
    if(identical(SLO,numeric(0)) ){
      #If growth rate doesn't exist, just use slope 0
      SLO <- 0
    }
    
    Lag <- ab$Msx[ab$Strain3== c1$Strain[i]]
    if(identical(Lag,numeric(0)) ){
      #If lagtime doesn't exist [since they didnt grow], just use Idur
      Lag <- Idur
    }
    
    if( identical(sign(Idur-Lag),-1) ){
      #If lagtime is longer than duration, they dont grow ?
      # c1$cells[i] <- c1$cells[i]*(1+SLO)^(Idur-Lag) 
      
    } else { 
      
      c1$cells[i] <- c1$cells[i]*(1+SLO)^(Idur-Lag)
    }
    
    
  }
  c1
  
}



library(plotly)

#### 3d plot section
#Do similar functions for surface plots as CHangingplot and Constantplot
TDsurfaceconstant <- function(Finaldata,dur, nint, Z, skew=NULL, PLOT){
  
  
  #Constant conditions, ph1 = ph2
  jeez <- data.frame()
  # for(z in 1:10){
  for(i in 5:9){
    for(j in 1:length(unique(Finaldata$Strain3))){
      
      test <- P2dfgen(i,i,subset(Finaldata, Finaldata$Strain3 ==  unique(Finaldata$Strain3)[j] ),dur,nint,Z, skew)
      
      # test <- P2dfgen(i,i,subset(Finaldata,Finaldata$Strain3 != "CTXCMY"),dur,nint,Z)
      
      test$pH <- i
      # test$z <- z*0.1
      
      jeez <- rbind(jeez, test)
      
      # break()
      
    }
  }
  # }
  
  jeez$Conc <- as.numeric(jeez$Conc)
  jeez$pH <- as.numeric(jeez$pH )
  
  # Phasedf$Strain[is.na(Phasedf$Strain)] <- "blank"
  
  Phase2 <- subset(jeez, !(jeez$Conc %in% c(0)) & !( jeez$Strain %in% c("Blank")))
  Phase2$RF <- as.numeric(Phase2$RF)
  
A1 <- subset(Phase2,Phase2$Strain == unique(Phase2$Strain)[1])

A1$RF <- as.numeric(A1$RF)
# A1$RF <- as.numeric(A1$log2cells)

DF1 <- matrix(ncol = 10, nrow = 5)
for(i in 1:length(unique(Phase2$Conc))){
  
  DF1[1,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[1] ][1]
  DF1[2,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[2] ][1]
  DF1[3,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[3] ][1]
  DF1[4,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[4] ][1]
  DF1[5,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[5] ][1]
  
}
A1 <- subset(Phase2,Phase2$Strain == unique(Phase2$Strain)[2])


A1$RF <- as.numeric(A1$RF)
# A1$RF <- as.numeric(A1$log2cells)

DF2 <- matrix(ncol = 10, nrow = 5)
for(i in 1:length(unique(Phase2$Conc))){
  
  DF2[1,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[1] ][1]
  DF2[2,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[2] ][1]
  DF2[3,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[3] ][1]
  DF2[4,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[4] ][1]
  DF2[5,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[5] ][1]
  
}

A1 <- subset(Phase2,Phase2$Strain == unique(Phase2$Strain)[3])

A1$RF <- as.numeric(A1$RF)
# A1$RF <- as.numeric(A1$log2cells)

DF3 <- matrix(ncol = 10, nrow = 5)
for(i in 1:length(unique(Phase2$Conc))){
  
  DF3[1,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[1] ][1]
  DF3[2,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[2] ][1]
  DF3[3,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[3] ][1]
  DF3[4,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[4] ][1]
  DF3[5,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[5] ][1]
  
}

A1 <- subset(Phase2,Phase2$Strain == unique(Phase2$Strain)[4])

A1$RF <- as.numeric(A1$RF)
# A1$RF <- as.numeric(A1$log2cells)

DF4 <- matrix(ncol = 10, nrow = 5)
for(i in 1:length(unique(Phase2$Conc))){
  
  DF4[1,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[1] ][1]
  DF4[2,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[2] ][1]
  DF4[3,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[3] ][1]
  DF4[4,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[4] ][1]
  DF4[5,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[5] ][1]
  
}

A1 <- subset(Phase2,Phase2$Strain == unique(Phase2$Strain)[5])

A1$RF <- as.numeric(A1$RF)
# A1$RF <- as.numeric(A1$log2cells)

DF5 <- matrix(ncol = 10, nrow = 5)
for(i in 1:length(unique(Phase2$Conc))){
  
  DF5[1,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[1] ][1]
  DF5[2,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[2] ][1]
  DF5[3,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[3] ][1]
  DF5[4,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[4] ][1]
  DF5[5,i] <- A1$RF[A1$Conc == unique(Phase2$Conc)[i] & A1$pH == unique(A1$pH)[5] ][1]
  
}


# A1$RF[A1$Conc == unique(A1$Conc)[i] & A1$pH == unique(A1$pH)[10] ][1]

# test <- volcano
# 

fig <- plot_ly( x =c(5,6,7,8,9), y = seq(-3,6,1) , showlegend = TRUE)
# 

if(PLOT == 1){
# color1 <- "red" for excluding ctxcmy
fig <- fig %>% add_surface(z = ~t(DF1), name = "K12", colorscale=list(list(0, "#2E772B"), list(1,"#9EFF9B")),
                           showscale=FALSE)
# color1 <- "orange"
# fig <- fig %>% add_surface(z = ~t(DF2), colorscale=list(list(0, color1), list(1,color1)),
#                            showscale=FALSE)
# color1 <- "purple"
fig <- fig %>% add_surface(z = ~t(DF2),name = "CMYCTX", colorscale=list(list(0, "#310B38"), list(1,"#F19BFF")),
showscale=FALSE)
# color1 <- "blue"
fig <- fig %>% add_surface(z = ~t(DF3), name = "CTX-M-15", colorscale=list(list(0, "#152B3A"), list(1,"#B5DEFF")),
                           showscale=FALSE)
# color1 <- "green"
fig <- fig %>% add_surface(z = ~t(DF4), name = "CMY-2", colorscale=list(list(0, "#350D10"), list(1,"#FF7C81")),
                           showscale=FALSE)
}


# #For excluding ctxcmy and cmyctx
if(PLOT == 2){

fig <- fig %>% add_surface(z = ~t(DF1), name = "K12", colorscale=list(list(0, "#2E772B"), list(1,"#9EFF9B")),
                           showscale=FALSE)
fig <- fig %>% add_surface(z = ~t(DF2), name = "CTX-M-15", colorscale=list(list(0, "#152B3A"), list(1,"#B5DEFF")),
                           showscale=FALSE)
# color1 <- "green"
fig <- fig %>% add_surface(z = ~t(DF3), name = "CMY-2", colorscale=list(list(0, "#350D10"), list(1,"#FF7C81")),
                           showscale=FALSE)
}

# 
# fig %>% layout()
fig <- fig %>% layout(scene = list( yaxis = list(title = "Conc", tickvals = (c(-3,-2,-1,0,1,2,3,4,5)),ticktext = ( as.character(c(0.125,0.25,0.5,1,2,4,8,16,32)) )), zaxis = list(title = "Fitness"), xaxis = list(title = "pH" , type = "category", ticktext = list(factor(A1$pH))
                                                                                                                     # tickvals = list(unique(A1$pH))
                                                                                                                     )) )


fig
# 
}


#For figure 3 A:
hey <- TDsurfaceconstant(subset(Finaldata,!Finaldata$Strain3 %in% c("CTXCMY")), 300, 4, 0.3, PLOT = 1)

#For figure 3 B:
hey <- TDsurfaceconstant(subset(Finaldata,!Finaldata$Strain3 %in% c("CTXCMY","CMYCTX")), 300, 4, 0.3, PLOT = 2)



hey2 <- hey %>% layout(scene = list(camera = list(eye = list( x = 1.5, y = 1.5, z = 1.5))))


library(reticulate)
reticulate::use_miniconda("r-reticulate")


# reticulate::py_run_string("import sys") #needed to install below
# reticulate::conda_install('r-reticulate', 'python-kaleido==0.1.*') #to install packages to actually save the plot as svg


save_image(p = hey2, "plot1.svg", scale = 4, height = 800, width = 1000)




#Save interactive htmls:

htmlwidgets::saveWidget(as_widget(hey), "Plot1.html")


